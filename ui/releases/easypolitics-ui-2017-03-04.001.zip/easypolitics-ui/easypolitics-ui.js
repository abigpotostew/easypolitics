(function (root, factory) {
  if (typeof define === 'function' && define.amd)
    define('easypolitics-ui', ['exports', 'kotlin'], factory);
  else if (typeof exports === 'object')
    factory(module.exports, require('kotlin'));
  else {
    if (typeof kotlin === 'undefined') {
      throw new Error("Error loading module 'easypolitics-ui'. Its dependency 'kotlin' was not found. Please, check whether 'kotlin' is loaded prior to 'easypolitics-ui'.");
    }
    root['easypolitics-ui'] = factory(typeof this['easypolitics-ui'] === 'undefined' ? {} : this['easypolitics-ui'], kotlin);
  }
}(this, function (_, Kotlin) {
  'use strict';
  var println = Kotlin.kotlin.io.println_s8jyv4$;
  var isNaN_0 = Kotlin.kotlin.isNaN_yrwdxr$;
  var RuntimeException = Kotlin.kotlin.RuntimeException;
  var IllegalStateException = Kotlin.kotlin.IllegalStateException;
  var toList = Kotlin.kotlin.collections.toList_7wnvza$;
  var NullPointerException = Kotlin.kotlin.NullPointerException;
  var UnsupportedOperationException = Kotlin.kotlin.UnsupportedOperationException;
  var asList = Kotlin.org.w3c.dom.asList_kt9thq$;
  var ArrayList_init = Kotlin.kotlin.collections.ArrayList_init_ww73n8$;
  var replace = Kotlin.kotlin.text.replace_r2fvfm$;
  var Enum = Kotlin.kotlin.Enum;
  var IllegalArgumentException = Kotlin.kotlin.IllegalArgumentException;
  var toInt = Kotlin.kotlin.text.toInt_pdl1vz$;
  var NumberFormatException = Kotlin.kotlin.NumberFormatException;
  var Throwable = Error;
  var listOf = Kotlin.kotlin.collections.listOf_i5x0yv$;
  var NoSuchElementException = Kotlin.kotlin.NoSuchElementException;
  var Any = Object;
  var emptyList_0 = Kotlin.kotlin.collections.emptyList_287e2$;
  var union = Kotlin.kotlin.collections.union_q4559j$;
  var max = Kotlin.kotlin.collections.max_l63kqw$;
  var DoubleCompanionObject = Kotlin.kotlin.js.internal.DoubleCompanionObject;
  var min = Kotlin.kotlin.collections.min_l63kqw$;
  var HashSet_init = Kotlin.kotlin.collections.HashSet_init_287e2$;
  var HashMap_init = Kotlin.kotlin.collections.HashMap_init_q3lmfv$;
  var Pair = Kotlin.kotlin.Pair;
  var mapOf = Kotlin.kotlin.collections.mapOf_x2b85n$;
  var toMutableMap = Kotlin.kotlin.collections.toMutableMap_abgq59$;
  var sorted = Kotlin.kotlin.collections.sorted_exjks8$;
  var addClass = Kotlin.kotlin.dom.addClass_hhb33f$;
  var createElement = Kotlin.kotlin.dom.createElement_7cgwi1$;
  var IntRange = Kotlin.kotlin.ranges.IntRange;
  var Comparable = Kotlin.kotlin.Comparable;
  var plus = Kotlin.kotlin.collections.plus_mydzjv$;
  var plus_0 = Kotlin.kotlin.collections.plus_qloxvw$;
  var last = Kotlin.kotlin.collections.last_7wnvza$;
  var equals = Kotlin.kotlin.text.equals_igcy3c$;
  var Exception = Kotlin.kotlin.Exception;
  var ClassCastException = Kotlin.kotlin.ClassCastException;
  var Regex = Kotlin.kotlin.text.Regex_61zpoe$;
  ViewConstants.prototype = Object.create(Enum.prototype);
  ViewConstants.prototype.constructor = ViewConstants;
  BillController$downloadBillsLoadData$ObjectLiteral.prototype = Object.create(RequestCallback.prototype);
  BillController$downloadBillsLoadData$ObjectLiteral.prototype.constructor = BillController$downloadBillsLoadData$ObjectLiteral;
  BillController.prototype = Object.create(Controller.prototype);
  BillController.prototype.constructor = BillController;
  AbstractMappedIndex.prototype = Object.create(MappedIndex.prototype);
  AbstractMappedIndex.prototype.constructor = AbstractMappedIndex;
  STATUS_INDEX$ObjectLiteral.prototype = Object.create(AbstractMappedIndex.prototype);
  STATUS_INDEX$ObjectLiteral.prototype.constructor = STATUS_INDEX$ObjectLiteral;
  MAJOR_STATUS_INDEX$ObjectLiteral.prototype = Object.create(AbstractMappedIndex.prototype);
  MAJOR_STATUS_INDEX$ObjectLiteral.prototype.constructor = MAJOR_STATUS_INDEX$ObjectLiteral;
  PARTY_INDEX$ObjectLiteral.prototype = Object.create(AbstractMappedIndex.prototype);
  PARTY_INDEX$ObjectLiteral.prototype.constructor = PARTY_INDEX$ObjectLiteral;
  NumericDoubleAbstractMappedIndex.prototype = Object.create(AbstractMappedIndex.prototype);
  NumericDoubleAbstractMappedIndex.prototype.constructor = NumericDoubleAbstractMappedIndex;
  INTRO_DATE_INDEX$ObjectLiteral.prototype = Object.create(NumericDoubleAbstractMappedIndex.prototype);
  INTRO_DATE_INDEX$ObjectLiteral.prototype.constructor = INTRO_DATE_INDEX$ObjectLiteral;
  LAST_UPDATED_DATE_INDEX$ObjectLiteral.prototype = Object.create(NumericDoubleAbstractMappedIndex.prototype);
  LAST_UPDATED_DATE_INDEX$ObjectLiteral.prototype.constructor = LAST_UPDATED_DATE_INDEX$ObjectLiteral;
  EMPTY_INDEX$ObjectLiteral.prototype = Object.create(AbstractMappedIndex.prototype);
  EMPTY_INDEX$ObjectLiteral.prototype.constructor = EMPTY_INDEX$ObjectLiteral;
  IndexEnum.prototype = Object.create(Enum.prototype);
  IndexEnum.prototype.constructor = IndexEnum;
  IndexOperation.prototype = Object.create(Enum.prototype);
  IndexOperation.prototype.constructor = IndexOperation;
  LogLevel.prototype = Object.create(Enum.prototype);
  LogLevel.prototype.constructor = LogLevel;
  BillView$makeAnimation$ObjectLiteral.prototype = Object.create(Animation.prototype);
  BillView$makeAnimation$ObjectLiteral.prototype.constructor = BillView$makeAnimation$ObjectLiteral;
  BillView.prototype = Object.create(View.prototype);
  BillView.prototype.constructor = BillView;
  Form.prototype = Object.create(Enum.prototype);
  Form.prototype.constructor = Form;
  Form$Option.prototype = Object.create(Form.prototype);
  Form$Option.prototype.constructor = Form$Option;
  Identifier.prototype = Object.create(Enum.prototype);
  Identifier.prototype.constructor = Identifier;
  BillFilters.prototype = Object.create(Enum.prototype);
  BillFilters.prototype.constructor = BillFilters;
  Party.prototype = Object.create(Enum.prototype);
  Party.prototype.constructor = Party;
  LegislatorRole.prototype = Object.create(Enum.prototype);
  LegislatorRole.prototype.constructor = LegislatorRole;
  FixedStatus.prototype = Object.create(Enum.prototype);
  FixedStatus.prototype.constructor = FixedStatus;
  MajorStatus.prototype = Object.create(Enum.prototype);
  MajorStatus.prototype.constructor = MajorStatus;
  BillResolutionType.prototype = Object.create(Enum.prototype);
  BillResolutionType.prototype.constructor = BillResolutionType;
  BillType.prototype = Object.create(Enum.prototype);
  BillType.prototype.constructor = BillType;
  function main$lambda(closure$controller) {
    return function (it) {
      closure$controller.showBills();
      closure$controller.view.setLoading_6taknv$(false);
      println('done loading');
    };
  }
  function main(args) {
    var rootElement = new HtmlSelector(Identifier$ID_getInstance(), 'bills');
    var controller = new BillController(rootElement);
    controller.view.setLoading_6taknv$(true);
    controller.view.saveElementTemplate_ysjsms$('bill', rootElement);
    controller.view.clearRoot();
    controller.downloadBillsLoadData_jgi7ky$('https://www.govtrack.us/api/v2/bill?congress=115&order_by=-current_status_date&limit=200', main$lambda(controller));
  }
  function printMajorActionData(controller) {
    var tmp$, tmp$_0, tmp$_1;
    var bills = controller.model.getBillData();
    var destination = Kotlin.kotlin.collections.LinkedHashMap_init_q3lmfv$();
    var tmp$_2;
    tmp$_2 = bills.iterator();
    while (tmp$_2.hasNext()) {
      var element = tmp$_2.next();
      var key = element.lastMajorAction().id();
      var tmp$_3;
      var value = destination.get_11rb$(key);
      if (value == null) {
        var answer = Kotlin.kotlin.collections.ArrayList_init_ww73n8$();
        destination.put_xwzc9p$(key, answer);
        tmp$_3 = answer;
      }
       else {
        tmp$_3 = value;
      }
      var list = tmp$_3;
      list.add_11rb$(element);
    }
    var grouped = destination;
    println(grouped);
    println('---------');
    println(grouped.keys);
    println('---------');
    tmp$ = grouped.keys.iterator();
    while (tmp$.hasNext()) {
      var k = tmp$.next();
      println('---------');
      println(k.toString() + ' size ' + Kotlin.toString((tmp$_0 = grouped.get_11rb$(k)) != null ? tmp$_0.size : null));
      var tmp$_4;
      if ((tmp$_1 = grouped.get_11rb$(k)) != null) {
        var destination_0 = Kotlin.kotlin.collections.LinkedHashMap_init_q3lmfv$();
        var tmp$_5;
        tmp$_5 = tmp$_1.iterator();
        while (tmp$_5.hasNext()) {
          var element_0 = tmp$_5.next();
          var tmp$_7;
          var key_0 = (Kotlin.isType(tmp$_7 = element_0, BillData) ? tmp$_7 : Kotlin.throwCCE()).lastMajorAction().description();
          var tmp$_6;
          var value_0 = destination_0.get_11rb$(key_0);
          if (value_0 == null) {
            var answer_0 = Kotlin.kotlin.collections.ArrayList_init_ww73n8$();
            destination_0.put_xwzc9p$(key_0, answer_0);
            tmp$_6 = answer_0;
          }
           else {
            tmp$_6 = value_0;
          }
          var list_0 = tmp$_6;
          list_0.add_11rb$(element_0);
        }
        tmp$_4 = destination_0;
      }
       else
        tmp$_4 = null;
      println(tmp$_4);
      println('---------');
    }
  }
  function Controller(view, model) {
    this.view = view;
    this.model = model;
  }
  Controller.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'Controller',
    interfaces: []
  };
  function clamp($receiver, v, lo, hi) {
    return v < lo ? lo : v > hi ? hi : v;
  }
  function niceClamp($receiver, v, lo, hi, preferLo) {
    println('v: ' + v + ', lo: ' + lo + ', hi: ' + hi + ', preferLo: ' + preferLo);
    if (isNaN_0(v)) {
      if (preferLo)
        return lo;
      else
        return hi;
    }
    return v < lo ? lo : v > hi ? hi : v;
  }
  function BillModelGovTrack() {
    this.bills_0 = Kotlin.kotlin.collections.LinkedHashMap_init_q3lmfv$();
    this.latestBillData_0 = null;
  }
  BillModelGovTrack.prototype.loadBillData_za3rmp$ = function (data) {
    var billObjects = data['objects'];
    var n = data.objects.length;
    var i = 0;
    while (i < n) {
      try {
        var o = billObjects[i];
        var bill = (new BillDataGovTrack(this)).build_za3rmp$(o);
        this.bills_0.put_xwzc9p$(o.id, bill);
      }
       catch (e) {
        if (Kotlin.isType(e, IllegalStateException)) {
          throw new RuntimeException('Issue parsing bill data, please improve this exception to see which parse failed: \n\t' + e.toString());
        }
         else
          throw e;
      }
      i = i + 1 | 0;
    }
    this.latestBillData_0 = data;
  };
  BillModelGovTrack.prototype.getBillData = function () {
    return toList(this.bills_0.values);
  };
  BillModelGovTrack.prototype.indexData = function () {
    var tmp$;
    tmp$ = ALL_INDEX_DEFS.iterator();
    while (tmp$.hasNext()) {
      var idx = tmp$.next();
      idx.indexInstances_brywmv$(this.bills_0.values);
    }
  };
  BillModelGovTrack.prototype.getBillById_za3lpa$ = function (uniqueId) {
    return this.bills_0.get_11rb$(uniqueId);
  };
  BillModelGovTrack.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'BillModelGovTrack',
    interfaces: [Model]
  };
  function Model() {
  }
  Model.$metadata$ = {
    kind: Kotlin.Kind.INTERFACE,
    simpleName: 'Model',
    interfaces: []
  };
  function ModelItem() {
  }
  ModelItem.$metadata$ = {
    kind: Kotlin.Kind.INTERFACE,
    simpleName: 'ModelItem',
    interfaces: []
  };
  function RequestCallback() {
  }
  RequestCallback.prototype.onProgress = function () {
  };
  RequestCallback.prototype.onLoad_za3rmp$ = function (response) {
  };
  RequestCallback.prototype.onError = function () {
  };
  RequestCallback.prototype.onCancel = function () {
  };
  RequestCallback.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'RequestCallback',
    interfaces: []
  };
  function ServerRequestDispatcher() {
    this.CONTENT_TYPE_HEADER_0 = 'Content-Type';
    this.ACCEPT_HEADER_0 = 'Accept';
  }
  function ServerRequestDispatcher$sendRequest$ObjectLiteral(closure$callback) {
    this.closure$callback = closure$callback;
  }
  ServerRequestDispatcher$sendRequest$ObjectLiteral.prototype.handleEvent = function (event) {
    this.closure$callback.onProgress();
  };
  ServerRequestDispatcher$sendRequest$ObjectLiteral.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    interfaces: []
  };
  function ServerRequestDispatcher$sendRequest$ObjectLiteral_0(closure$callback, closure$request) {
    this.closure$callback = closure$callback;
    this.closure$request = closure$request;
  }
  ServerRequestDispatcher$sendRequest$ObjectLiteral_0.prototype.handleEvent = function (event) {
    this.closure$callback.onLoad_za3rmp$(this.closure$request.response);
  };
  ServerRequestDispatcher$sendRequest$ObjectLiteral_0.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    interfaces: []
  };
  function ServerRequestDispatcher$sendRequest$ObjectLiteral_1(closure$callback) {
    this.closure$callback = closure$callback;
  }
  ServerRequestDispatcher$sendRequest$ObjectLiteral_1.prototype.handleEvent = function (event) {
    this.closure$callback.onError();
  };
  ServerRequestDispatcher$sendRequest$ObjectLiteral_1.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    interfaces: []
  };
  function ServerRequestDispatcher$sendRequest$ObjectLiteral_2(closure$callback) {
    this.closure$callback = closure$callback;
  }
  ServerRequestDispatcher$sendRequest$ObjectLiteral_2.prototype.handleEvent = function (event) {
    this.closure$callback.onCancel();
  };
  ServerRequestDispatcher$sendRequest$ObjectLiteral_2.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    interfaces: []
  };
  ServerRequestDispatcher.prototype.sendRequest_v8zplp$ = function (path, callback) {
    if (callback === void 0)
      callback = null;
    var request = new XMLHttpRequest();
    request.open('GET', path, true);
    request.setRequestHeader(this.ACCEPT_HEADER_0, 'application/xml');
    request.setRequestHeader(this.CONTENT_TYPE_HEADER_0, 'application/x-www-form-urlencoded');
    if (callback != null) {
      request.addEventListener('progress', new ServerRequestDispatcher$sendRequest$ObjectLiteral(callback));
      request.addEventListener('load', new ServerRequestDispatcher$sendRequest$ObjectLiteral_0(callback, request));
      request.addEventListener('error', new ServerRequestDispatcher$sendRequest$ObjectLiteral_1(callback));
      request.addEventListener('abort', new ServerRequestDispatcher$sendRequest$ObjectLiteral_2(callback));
    }
    request.send();
    return request;
  };
  ServerRequestDispatcher.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'ServerRequestDispatcher',
    interfaces: []
  };
  function JsonUtil() {
    JsonUtil$Parse_getInstance();
  }
  function JsonUtil$Parse() {
    JsonUtil$Parse_instance = this;
  }
  JsonUtil$Parse.prototype.parse_61zpoe$ = function (string) {
    return JSON.parse(string);
  };
  JsonUtil$Parse.prototype.niceString_61zpoe$ = function (str) {
    return '' + Kotlin.toString(str);
  };
  JsonUtil$Parse.$metadata$ = {
    kind: Kotlin.Kind.OBJECT,
    simpleName: 'Parse',
    interfaces: []
  };
  var JsonUtil$Parse_instance = null;
  function JsonUtil$Parse_getInstance() {
    if (JsonUtil$Parse_instance === null) {
      new JsonUtil$Parse();
    }
    return JsonUtil$Parse_instance;
  }
  JsonUtil.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'JsonUtil',
    interfaces: []
  };
  function Math_0() {
    Math$Ease_getInstance();
  }
  function Math$Ease() {
    Math$Ease_instance = this;
  }
  Math$Ease.prototype.easeInOutQuad_6y0v78$ = function (t, b, c, d) {
    var ti = t / (d / 2);
    if (t < 1)
      return c / 2 * ti * ti + b;
    ti = ti - 1;
    return -c / 2 * (ti * (t - 2) - 1) + b;
  };
  Math$Ease.$metadata$ = {
    kind: Kotlin.Kind.OBJECT,
    simpleName: 'Ease',
    interfaces: []
  };
  var Math$Ease_instance = null;
  function Math$Ease_getInstance() {
    if (Math$Ease_instance === null) {
      new Math$Ease();
    }
    return Math$Ease_instance;
  }
  Math_0.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'Math',
    interfaces: []
  };
  function HtmlGen() {
    this.templates = Kotlin.kotlin.collections.LinkedHashMap_init_q3lmfv$();
  }
  HtmlGen.prototype.addElement_puj7f4$ = function (name, htmlString) {
    this.templates.put_xwzc9p$(name, htmlString);
  };
  HtmlGen.prototype.buildElement_61zpoe$ = function (name) {
    var str = this.templates.get_11rb$(name);
    if (str != null) {
      return $(str);
    }
    throw new NullPointerException("HTML template with name '" + name + " doesn't exist.");
  };
  HtmlGen.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'HtmlGen',
    interfaces: []
  };
  function HtmlSelector(identifier, selectorText) {
    if (identifier === void 0)
      identifier = Identifier$TAG_getInstance();
    if (selectorText === void 0)
      selectorText = '';
    this.identifier_0 = identifier;
    this.selectorText_0 = selectorText;
    this.textCache_0 = this.identifier_0.getPrefix() + this.selectorText_0;
  }
  HtmlSelector.prototype.toString = function () {
    return this.text();
  };
  HtmlSelector.prototype.text = function () {
    return this.textCache_0;
  };
  HtmlSelector.prototype.prefix = function () {
    return this.identifier_0.getPrefix();
  };
  HtmlSelector.prototype.suffix = function () {
    return this.selectorText_0;
  };
  HtmlSelector.prototype.addToJqElement_jlc00i$ = function (obj) {
    var tmp$;
    tmp$ = this.identifier_0;
    if (Kotlin.equals(tmp$, Identifier$ID_getInstance()))
      obj.attr('id', this.suffix());
    else if (Kotlin.equals(tmp$, Identifier$CLASS_getInstance()))
      obj.addClass(this.suffix());
    else if (Kotlin.equals(tmp$, Identifier$TAG_getInstance()))
      throw new UnsupportedOperationException("Can't add a tag to a class.");
    else
      Kotlin.noWhenBranchMatched();
  };
  HtmlSelector.prototype.getElements = function () {
    var tmp$, tmp$_0;
    tmp$ = this.identifier_0;
    if (Kotlin.equals(tmp$, Identifier$CLASS_getInstance()))
      return asList(document.getElementsByClassName(this.suffix()));
    else if (Kotlin.equals(tmp$, Identifier$ID_getInstance())) {
      var elm = document.getElementById(this.suffix());
      if (elm != null) {
        var list = Kotlin.kotlin.collections.ArrayList_init_ww73n8$(1);
        var tmp$_1;
        tmp$_1 = 1 - 1 | 0;
        for (var index = 0; index <= tmp$_1; index++) {
          list.add_11rb$(elm);
        }
        return toList(list);
      }
      return ArrayList_init();
    }
     else if (Kotlin.equals(tmp$, Identifier$TAG_getInstance()))
      tmp$_0 = asList(document.getElementsByTagName(this.suffix()));
    else
      tmp$_0 = Kotlin.noWhenBranchMatched();
    return tmp$_0;
  };
  HtmlSelector.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'HtmlSelector',
    interfaces: []
  };
  function View(rootElementSelector) {
    if (rootElementSelector === void 0)
      rootElementSelector = new HtmlSelector(Identifier$TAG_getInstance(), 'body');
    this.rootElementSelector = rootElementSelector;
    this.loading = false;
    this.htmlGen = new HtmlGen();
  }
  View.prototype.setLoading_6taknv$ = function (isLoading) {
    this.loading = isLoading;
  };
  View.prototype.saveElementTemplate_ysjsms$ = function (templateName, contentsOf) {
    this.htmlGen.addElement_puj7f4$(templateName, this.getJq_q0rfmm$(contentsOf).html());
  };
  View.prototype.clearRoot = function () {
    this.getJq_q0rfmm$(this.rootElementSelector).children().remove();
  };
  View.prototype.getElement_q0rfmm$ = function (selector) {
    return get(this.getJq_q0rfmm$(selector), 0);
  };
  View.prototype.getJq_q0rfmm$ = function (selector) {
    return $(selector.text());
  };
  View.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'View',
    interfaces: []
  };
  function ViewConstant() {
  }
  ViewConstant.$metadata$ = {
    kind: Kotlin.Kind.INTERFACE,
    simpleName: 'ViewConstant',
    interfaces: []
  };
  function ViewConstantHelper(niceString) {
    this.niceString_0 = niceString;
    this.xmlName = replace(this.niceString_0.toUpperCase(), 32, 95);
    this.caps = this.xmlName;
    this.lowerCase = this.caps.toLowerCase();
  }
  ViewConstantHelper.prototype.lowercaseName = function () {
    return this.lowerCase;
  };
  ViewConstantHelper.prototype.capitalizedName = function () {
    return this.caps;
  };
  ViewConstantHelper.prototype.niceFormat = function () {
    return this.niceString_0;
  };
  ViewConstantHelper.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'ViewConstantHelper',
    interfaces: []
  };
  function ViewConstants(name, ordinal, niceString, shortLabel) {
    Enum.call(this);
    this.shortLabel_vzu3p4$_0 = shortLabel;
    this.name$ = name;
    this.ordinal$ = ordinal;
    this.helper_vzu3p4$_0 = new ViewConstantHelper(niceString);
  }
  function ViewConstants_initFields() {
    ViewConstants_initFields = function () {
    };
    ViewConstants$Empty_instance = new ViewConstants('Empty', 0, '', '');
    ViewConstants$Introduced_instance = new ViewConstants('Introduced', 1, 'Introduced', 'Introduced');
    ViewConstants$Failed_instance = new ViewConstants('Failed', 2, 'Failed', 'Failed');
    ViewConstants$PassedHouse_instance = new ViewConstants('PassedHouse', 3, 'Passed House', 'P.H.');
    ViewConstants$PassedSenate_instance = new ViewConstants('PassedSenate', 4, 'Passed Senate', 'P.H.');
    ViewConstants$SignedByPresident_instance = new ViewConstants('SignedByPresident', 5, 'Signed by President', 'Signed');
    ViewConstants$EnactedLaw_instance = new ViewConstants('EnactedLaw', 6, 'Enacted Law', 'Enacted');
  }
  var ViewConstants$Empty_instance;
  function ViewConstants$Empty_getInstance() {
    ViewConstants_initFields();
    return ViewConstants$Empty_instance;
  }
  var ViewConstants$Introduced_instance;
  function ViewConstants$Introduced_getInstance() {
    ViewConstants_initFields();
    return ViewConstants$Introduced_instance;
  }
  var ViewConstants$Failed_instance;
  function ViewConstants$Failed_getInstance() {
    ViewConstants_initFields();
    return ViewConstants$Failed_instance;
  }
  var ViewConstants$PassedHouse_instance;
  function ViewConstants$PassedHouse_getInstance() {
    ViewConstants_initFields();
    return ViewConstants$PassedHouse_instance;
  }
  var ViewConstants$PassedSenate_instance;
  function ViewConstants$PassedSenate_getInstance() {
    ViewConstants_initFields();
    return ViewConstants$PassedSenate_instance;
  }
  var ViewConstants$SignedByPresident_instance;
  function ViewConstants$SignedByPresident_getInstance() {
    ViewConstants_initFields();
    return ViewConstants$SignedByPresident_instance;
  }
  var ViewConstants$EnactedLaw_instance;
  function ViewConstants$EnactedLaw_getInstance() {
    ViewConstants_initFields();
    return ViewConstants$EnactedLaw_instance;
  }
  ViewConstants.prototype.lowercaseName = function () {
    return this.helper_vzu3p4$_0.lowercaseName();
  };
  ViewConstants.prototype.capitalizedName = function () {
    return this.helper_vzu3p4$_0.capitalizedName();
  };
  ViewConstants.prototype.niceFormat = function () {
    return this.helper_vzu3p4$_0.niceFormat();
  };
  ViewConstants.prototype.shortLabel = function () {
    return this.shortLabel_vzu3p4$_0;
  };
  ViewConstants.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'ViewConstants',
    interfaces: [ViewConstant, Enum]
  };
  function ViewConstants$values() {
    return [ViewConstants$Empty_getInstance(), ViewConstants$Introduced_getInstance(), ViewConstants$Failed_getInstance(), ViewConstants$PassedHouse_getInstance(), ViewConstants$PassedSenate_getInstance(), ViewConstants$SignedByPresident_getInstance(), ViewConstants$EnactedLaw_getInstance()];
  }
  ViewConstants.values = ViewConstants$values;
  function ViewConstants$valueOf(name) {
    switch (name) {
      case 'Empty':
        return ViewConstants$Empty_getInstance();
      case 'Introduced':
        return ViewConstants$Introduced_getInstance();
      case 'Failed':
        return ViewConstants$Failed_getInstance();
      case 'PassedHouse':
        return ViewConstants$PassedHouse_getInstance();
      case 'PassedSenate':
        return ViewConstants$PassedSenate_getInstance();
      case 'SignedByPresident':
        return ViewConstants$SignedByPresident_getInstance();
      case 'EnactedLaw':
        return ViewConstants$EnactedLaw_getInstance();
      default:Kotlin.throwISE('No enum constant bz.stew.bracken.view.ViewConstants.' + name);
    }
  }
  ViewConstants.valueOf_61zpoe$ = ViewConstants$valueOf;
  function BillController(rootElmt) {
    Controller.call(this, new BillView(rootElmt), new BillModelGovTrack());
  }
  BillController.prototype.onParseError = function () {
    throw new RuntimeException('');
  };
  BillController.prototype.applyFilter_fedbiw$ = function (filter_0, selectVal) {
    var tmp$, tmp$_0;
    var $receiver = (Kotlin.isType(tmp$ = this.model, BillModelGovTrack) ? tmp$ : Kotlin.throwCCE()).getBillData();
    var destination = Kotlin.kotlin.collections.ArrayList_init_ww73n8$();
    var tmp$_1;
    tmp$_1 = $receiver.iterator();
    while (tmp$_1.hasNext()) {
      var element = tmp$_1.next();
      if (filter_0.predicate(element, selectVal)) {
        destination.add_11rb$(element);
      }
    }
    var filtered = destination;
    (Kotlin.isType(tmp$_0 = this.view, BillView) ? tmp$_0 : Kotlin.throwCCE()).showSelectedBills_815ehw$(filtered);
  };
  function BillController$startListeningFilterForms$lambda(this$BillController) {
    return function (it) {
      this$BillController.introducedDateFilter_rjun73$(it, IndexOperation$GreaterThanOrEqual_getInstance());
    };
  }
  function BillController$startListeningFilterForms$lambda_0(this$BillController) {
    return function (it) {
      this$BillController.introducedDateFilter_rjun73$(it, IndexOperation$LessThanOrEqual_getInstance());
    };
  }
  BillController.prototype.startListeningFilterForms = function () {
    this.view.getElement_q0rfmm$(BillFilters$PARTY_getInstance().htmlSelector()).addEventListener('change', Kotlin.getCallableRef('partyFilter', function ($receiver, event) {
      return $receiver.partyFilter_9ojx7i$(event);
    }.bind(null, this)));
    this.view.getElement_q0rfmm$(BillFilters$FIXEDSTATUS_getInstance().htmlSelector()).addEventListener('change', Kotlin.getCallableRef('billStatusFilter', function ($receiver, event) {
      return $receiver.billStatusFilter_9ojx7i$(event);
    }.bind(null, this)));
    this.view.getElement_q0rfmm$(BillFilters$DATEINTROSTART_getInstance().htmlSelector()).addEventListener('change', BillController$startListeningFilterForms$lambda(this));
    this.view.getElement_q0rfmm$(BillFilters$DATEINTROEND_getInstance().htmlSelector()).addEventListener('change', BillController$startListeningFilterForms$lambda_0(this));
    this.view.getElement_q0rfmm$(BillFilters$LASTMAJORSTATUS_getInstance().htmlSelector()).addEventListener('change', Kotlin.getCallableRef('billMajorStatusFilter', function ($receiver, event) {
      return $receiver.billMajorStatusFilter_9ojx7i$(event);
    }.bind(null, this)));
  };
  BillController.prototype.stopListening = function () {
    this.view.getElement_q0rfmm$(BillFilters$PARTY_getInstance().htmlSelector()).removeEventListener('change', Kotlin.getCallableRef('partyFilter', function ($receiver, event) {
      return $receiver.partyFilter_9ojx7i$(event);
    }.bind(null, this)));
    this.view.getElement_q0rfmm$(BillFilters$FIXEDSTATUS_getInstance().htmlSelector()).removeEventListener('change', Kotlin.getCallableRef('billStatusFilter', function ($receiver, event) {
      return $receiver.billStatusFilter_9ojx7i$(event);
    }.bind(null, this)));
  };
  BillController.prototype.introducedDateFilter_rjun73$ = function (event, operator) {
    var tmp$, tmp$_0;
    var target = event.target;
    if (target != null && Kotlin.isType(target, HTMLInputElement)) {
      try {
        tmp$ = target.valueAsNumber;
      }
       catch (e) {
        if (Kotlin.isType(e, IllegalArgumentException)) {
          tmp$ = 0.0;
        }
         else
          throw e;
      }
      var inputDate = tmp$;
      var validDate = niceClamp(Math, inputDate, INTRO_DATE_INDEX.minKey(), INTRO_DATE_INDEX.maxKey(), operator === IndexOperation$GreaterThanOrEqual_getInstance());
      println('VALUE IS: ' + validDate);
      (Kotlin.isType(tmp$_0 = this.view, BillView) ? tmp$_0 : Kotlin.throwCCE()).showSelectedBills_815ehw$(INTRO_DATE_INDEX.instancesByOperator_dggtll$(operator, validDate));
    }
  };
  BillController.prototype.partyFilter_9ojx7i$ = function (event) {
    var tmp$, tmp$_0;
    var target = event.target;
    if (target != null && Kotlin.isType(target, HTMLSelectElement)) {
      try {
        tmp$ = Party$valueOf(target.value);
      }
       catch (e) {
        if (Kotlin.isType(e, IllegalArgumentException)) {
          tmp$ = Party$NONE_getInstance();
        }
         else
          throw e;
      }
      var party = tmp$;
      (Kotlin.isType(tmp$_0 = this.view, BillView) ? tmp$_0 : Kotlin.throwCCE()).showSelectedBills_815ehw$(PARTY_INDEX.instancesWith_11rb$(party));
    }
  };
  BillController.prototype.billMajorStatusFilter_9ojx7i$ = function (event) {
    var tmp$, tmp$_0;
    var target = event.target;
    if (target != null && Kotlin.isType(target, HTMLSelectElement)) {
      try {
        tmp$ = MajorStatus$Companion_getInstance().valueAt_za3lpa$(toInt(target.value));
      }
       catch (e) {
        if (Kotlin.isType(e, IllegalArgumentException)) {
          throw new RuntimeException('you fuxed up the status filter for select value of ' + target.value);
        }
         else if (Kotlin.isType(e, NumberFormatException)) {
          throw new RuntimeException('you fuxed up the status filter for select value of ' + target.value);
        }
         else
          throw e;
      }
      var majorStatus = tmp$;
      (Kotlin.isType(tmp$_0 = this.view, BillView) ? tmp$_0 : Kotlin.throwCCE()).showSelectedBills_815ehw$(MAJOR_STATUS_INDEX.instancesWith_11rb$(majorStatus));
    }
  };
  BillController.prototype.billStatusFilter_9ojx7i$ = function (event) {
    var tmp$, tmp$_0;
    var target = event.target;
    if (target != null && Kotlin.isType(target, HTMLSelectElement)) {
      try {
        tmp$ = FixedStatus$Companion_getInstance().valueAt_za3lpa$(toInt(target.value));
      }
       catch (e) {
        if (Kotlin.isType(e, IllegalArgumentException)) {
          throw new RuntimeException('you fuxed up the status filter for select value of ' + target.value);
        }
         else if (Kotlin.isType(e, NumberFormatException)) {
          throw new RuntimeException('you fuxed up the status filter for select value of ' + target.value);
        }
         else
          throw e;
      }
      var fixedStatus = tmp$;
      (Kotlin.isType(tmp$_0 = this.view, BillView) ? tmp$_0 : Kotlin.throwCCE()).showSelectedBills_815ehw$(STATUS_INDEX.instancesWith_11rb$(fixedStatus));
    }
  };
  BillController.prototype.showBills = function () {
    var tmp$;
    if (Kotlin.isType(this.view, BillView)) {
      this.view.initiateModelData_err50$((Kotlin.isType(tmp$ = this.model, BillModelGovTrack) ? tmp$ : Kotlin.throwCCE()).getBillData());
      this.model.indexData();
      this.view.loadStatusFilter_l3suxh$(STATUS_INDEX.filterType(), STATUS_INDEX.allKeys());
      this.view.loadMajorStatusFilter_qj2vly$(MAJOR_STATUS_INDEX.filterType(), MAJOR_STATUS_INDEX.allKeys());
      this.view.generateAndDisplayAllBills();
      this.startListeningFilterForms();
    }
  };
  function BillController$downloadBillsLoadData$ObjectLiteral(closure$controller, closure$onDownload) {
    this.closure$controller = closure$controller;
    this.closure$onDownload = closure$onDownload;
    RequestCallback.call(this);
  }
  BillController$downloadBillsLoadData$ObjectLiteral.prototype.onLoad_za3rmp$ = function (response) {
    var parse;
    try {
      parse = JsonUtil$Parse_getInstance().parse_61zpoe$(response);
      this.closure$controller.model.loadBillData_za3rmp$(parse);
    }
     catch (e) {
      if (Kotlin.isType(e, Throwable)) {
        var message = 'Error parsing json response from govtrack.us: \n\t' + e.toString();
        throw new Kotlin.kotlin.IllegalStateException(message.toString());
      }
       else
        throw e;
    }
    this.closure$onDownload(this.closure$controller);
  };
  BillController$downloadBillsLoadData$ObjectLiteral.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    interfaces: [RequestCallback]
  };
  BillController.prototype.downloadBillsLoadData_jgi7ky$ = function (requestUrl, onDownload) {
    var controller = this;
    (new ServerRequestDispatcher()).sendRequest_v8zplp$(requestUrl, new BillController$downloadBillsLoadData$ObjectLiteral(controller, onDownload));
  };
  BillController.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'BillController',
    interfaces: [Controller]
  };
  function DataRequest() {
  }
  DataRequest.$metadata$ = {
    kind: Kotlin.Kind.INTERFACE,
    simpleName: 'DataRequest',
    interfaces: []
  };
  var jsDate = Kotlin.defineInlineFunction('easypolitics-ui.bz.stew.bracken.extension.html.jsDate_qt1dr2$', function (year, month, day) {
    return new Date(year, month, day);
  });
  var jsDate_0 = Kotlin.defineInlineFunction('easypolitics-ui.bz.stew.bracken.extension.html.jsDate_tjonv8$', function (year, month, day, hour) {
    return new Date(year, month, day, hour);
  });
  var jsDate_1 = Kotlin.defineInlineFunction('easypolitics-ui.bz.stew.bracken.extension.html.jsDate', function () {
    return new Date();
  });
  function elementFixedOffset($receiver, el) {
    var tmp$, tmp$_0;
    var rect = el.getBoundingClientRect();
    var scrollLeft = window.pageXOffset !== 0.0 ? window.pageXOffset : ((tmp$ = $receiver.documentElement) != null ? tmp$ : Kotlin.throwNPE()).scrollLeft;
    var scrollTop = window.pageYOffset !== 0.0 ? window.pageYOffset : ((tmp$_0 = $receiver.documentElement) != null ? tmp$_0 : Kotlin.throwNPE()).scrollTop;
    var x = rect.left + scrollLeft;
    var y = rect.top + scrollTop;
    var z;
    var w;
    if (x === void 0) {
      x = 0;
    }
    if (y === void 0) {
      y = 0;
    }
    if (z === void 0) {
      z = 0;
    }
    if (w === void 0) {
      w = 1;
    }
    var o = {};
    o['x'] = x;
    o['y'] = y;
    o['z'] = z;
    o['w'] = w;
    return o;
  }
  function each($receiver, block) {
    var len = $receiver.length;
    for (var i = 0; i <= len; i++) {
      var elm = $receiver.item(i);
      if (elm != null)
        block(elm);
    }
  }
  function eachChildClass($receiver, className, block) {
    each($receiver.getElementsByClassName(className), block);
  }
  function eachChildId($receiver, idName, block) {
    var $receiver_0 = asList($receiver.getElementsByTagName('*'));
    var destination = Kotlin.kotlin.collections.ArrayList_init_ww73n8$();
    var tmp$;
    tmp$ = $receiver_0.iterator();
    while (tmp$.hasNext()) {
      var element = tmp$.next();
      if (Kotlin.equals(element.id, idName)) {
        destination.add_11rb$(element);
      }
    }
    var destination_0 = Kotlin.kotlin.collections.ArrayList_init_ww73n8$(Kotlin.kotlin.collections.collectionSizeOrDefault_ba2ldo$(destination, 10));
    var tmp$_0;
    tmp$_0 = destination.iterator();
    while (tmp$_0.hasNext()) {
      var item = tmp$_0.next();
      var tmp$_1 = destination_0.add_11rb$;
      var transform$result;
      block(item);
      tmp$_1.call(destination_0, transform$result);
    }
  }
  function asList_0($receiver) {
    var out = ArrayList_init();
    out.add_11rb$($receiver);
    return out;
  }
  var EMPTY_LIST;
  function emptyList($receiver) {
    return EMPTY_LIST;
  }
  var fadeIn = Kotlin.defineInlineFunction('easypolitics-ui.bz.stew.bracken.extension.jquery.fadeIn_v89ba5$', function ($receiver, speed) {
    return $receiver.fadeIn(speed);
  });
  function get($receiver, idx) {
    return $receiver[idx];
  }
  function hide($receiver) {
    return $receiver.hide();
  }
  function hide_0($receiver, dur) {
    return $receiver.hide(dur);
  }
  function hide_1($receiver, dur) {
    return $receiver.hide(dur);
  }
  var show = Kotlin.defineInlineFunction('easypolitics-ui.bz.stew.bracken.extension.jquery.show_vwohdt$', function ($receiver) {
    return $receiver.show();
  });
  var show_0 = Kotlin.defineInlineFunction('easypolitics-ui.bz.stew.bracken.extension.jquery.show_fjcsf1$', function ($receiver, dur) {
    return $receiver.show(dur);
  });
  var show_1 = Kotlin.defineInlineFunction('easypolitics-ui.bz.stew.bracken.extension.jquery.show_v89ba5$', function ($receiver, dur) {
    return $receiver.show(dur);
  });
  var append = Kotlin.defineInlineFunction('easypolitics-ui.bz.stew.bracken.extension.jquery.append_5kxll9$', function ($receiver, jQuery) {
    return $receiver.append(jQuery);
  });
  var children_0 = Kotlin.defineInlineFunction('easypolitics-ui.bz.stew.bracken.extension.jquery.children_5kxll9$', function ($receiver, jQuery) {
    return $receiver.children(jQuery);
  });
  var children = Kotlin.defineInlineFunction('easypolitics-ui.bz.stew.bracken.extension.jquery.children_vwohdt$', function ($receiver) {
    return $receiver.children();
  });
  var children_1 = Kotlin.defineInlineFunction('easypolitics-ui.bz.stew.bracken.extension.jquery.children_v89ba5$', function ($receiver, selector) {
    return $receiver.children(selector);
  });
  var first = Kotlin.defineInlineFunction('easypolitics-ui.bz.stew.bracken.extension.jquery.first_vwohdt$', function ($receiver) {
    return $receiver.first();
  });
  var remove = Kotlin.defineInlineFunction('easypolitics-ui.bz.stew.bracken.extension.jquery.remove_vwohdt$', function ($receiver) {
    return $receiver.remove();
  });
  var remove_0 = Kotlin.defineInlineFunction('easypolitics-ui.bz.stew.bracken.extension.jquery.remove_v89ba5$', function ($receiver, selector) {
    return $receiver.remove(selector);
  });
  var css = Kotlin.defineInlineFunction('easypolitics-ui.bz.stew.bracken.extension.jquery.css_zc05ld$', function ($receiver, prop, value) {
    return $receiver.css(prop, value);
  });
  var velocity = Kotlin.defineInlineFunction('easypolitics-ui.bz.stew.bracken.extension.jquery.velocity_c87r3m$', function ($receiver, prop, opts) {
    return $receiver.velcity(prop, opts);
  });
  function AbstractMappedIndex(allKey) {
    MappedIndex.call(this, allKey);
  }
  AbstractMappedIndex.prototype.indexInstances_brywmv$ = function (allInsts) {
    var tmp$;
    println('Indexing #' + allInsts.size + ' instances in index of type ?');
    tmp$ = allInsts.iterator();
    while (tmp$.hasNext()) {
      var b = tmp$.next();
      this.input_xwzc9p$(this.map_11rc$(b), b);
    }
  };
  AbstractMappedIndex.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'AbstractMappedIndex',
    interfaces: [FilterEntry, MappedIndex]
  };
  function STATUS_INDEX$ObjectLiteral(allKey) {
    AbstractMappedIndex.call(this, allKey);
  }
  STATUS_INDEX$ObjectLiteral.prototype.map_11rc$ = function (inst) {
    return inst.status.fixedStatus;
  };
  STATUS_INDEX$ObjectLiteral.prototype.filterType = function () {
    return BillFilters$FIXEDSTATUS_getInstance();
  };
  STATUS_INDEX$ObjectLiteral.prototype.allKeys = function () {
    return AbstractMappedIndex.prototype.allKeys.call(this);
  };
  STATUS_INDEX$ObjectLiteral.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    interfaces: [AbstractMappedIndex]
  };
  var STATUS_INDEX;
  function MAJOR_STATUS_INDEX$ObjectLiteral(allKey) {
    AbstractMappedIndex.call(this, allKey);
  }
  MAJOR_STATUS_INDEX$ObjectLiteral.prototype.map_11rc$ = function (inst) {
    return inst.lastMajorStatus();
  };
  MAJOR_STATUS_INDEX$ObjectLiteral.prototype.filterType = function () {
    return BillFilters$LASTMAJORSTATUS_getInstance();
  };
  MAJOR_STATUS_INDEX$ObjectLiteral.prototype.allKeys = function () {
    return AbstractMappedIndex.prototype.allKeys.call(this);
  };
  MAJOR_STATUS_INDEX$ObjectLiteral.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    interfaces: [AbstractMappedIndex]
  };
  var MAJOR_STATUS_INDEX;
  function PARTY_INDEX$ObjectLiteral(allKey) {
    AbstractMappedIndex.call(this, allKey);
  }
  PARTY_INDEX$ObjectLiteral.prototype.map_11rc$ = function (inst) {
    return inst.sponsor.getParty();
  };
  PARTY_INDEX$ObjectLiteral.prototype.filterType = function () {
    return BillFilters$PARTY_getInstance();
  };
  PARTY_INDEX$ObjectLiteral.prototype.allKeys = function () {
    return AbstractMappedIndex.prototype.allKeys.call(this);
  };
  PARTY_INDEX$ObjectLiteral.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    interfaces: [AbstractMappedIndex]
  };
  var PARTY_INDEX;
  function INTRO_DATE_INDEX$ObjectLiteral() {
    NumericDoubleAbstractMappedIndex.call(this);
  }
  INTRO_DATE_INDEX$ObjectLiteral.prototype.map_11rc$ = function (inst) {
    return inst.intro_date.getTime();
  };
  INTRO_DATE_INDEX$ObjectLiteral.prototype.filterType = function () {
    return BillFilters$DATEINTROSTART_getInstance();
  };
  INTRO_DATE_INDEX$ObjectLiteral.prototype.allKeys = function () {
    return NumericDoubleAbstractMappedIndex.prototype.allKeys.call(this);
  };
  INTRO_DATE_INDEX$ObjectLiteral.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    interfaces: [NumericDoubleAbstractMappedIndex]
  };
  var INTRO_DATE_INDEX;
  function LAST_UPDATED_DATE_INDEX$ObjectLiteral() {
    NumericDoubleAbstractMappedIndex.call(this);
  }
  LAST_UPDATED_DATE_INDEX$ObjectLiteral.prototype.map_11rc$ = function (inst) {
    return inst.lastUpdated();
  };
  LAST_UPDATED_DATE_INDEX$ObjectLiteral.prototype.filterType = function () {
    return BillFilters$LASTUPDATEDDATESTART_getInstance();
  };
  LAST_UPDATED_DATE_INDEX$ObjectLiteral.prototype.allKeys = function () {
    return NumericDoubleAbstractMappedIndex.prototype.allKeys.call(this);
  };
  LAST_UPDATED_DATE_INDEX$ObjectLiteral.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    interfaces: [NumericDoubleAbstractMappedIndex]
  };
  var LAST_UPDATED_DATE_INDEX;
  function EMPTY_INDEX$ObjectLiteral(allKey) {
    AbstractMappedIndex.call(this, allKey);
  }
  EMPTY_INDEX$ObjectLiteral.prototype.filterType = function () {
    return BillFilters$IDENTITY_getInstance();
  };
  EMPTY_INDEX$ObjectLiteral.prototype.map_11rc$ = function (inst) {
    return null;
  };
  EMPTY_INDEX$ObjectLiteral.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    interfaces: [AbstractMappedIndex]
  };
  var EMPTY_INDEX;
  var ALL_INDEX_DEFS;
  function IndexDefinitions() {
    IndexDefinitions$Companion_getInstance();
  }
  function IndexDefinitions$Companion() {
    IndexDefinitions$Companion_instance = this;
    this.allIndices_0 = Kotlin.kotlin.collections.LinkedHashMap_init_q3lmfv$();
  }
  IndexDefinitions$Companion.prototype.getIndex_2t4nz$ = function (def) {
    var idx = this.allIndices_0.get_11rb$(def);
    if (idx != null) {
      return idx;
    }
    throw new NoSuchElementException('derp');
  };
  IndexDefinitions$Companion.prototype.putIndex_lgzai8$ = function (newDef, idx) {
    this.allIndices_0.put_xwzc9p$(newDef, idx);
  };
  IndexDefinitions$Companion.$metadata$ = {
    kind: Kotlin.Kind.OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var IndexDefinitions$Companion_instance = null;
  function IndexDefinitions$Companion_getInstance() {
    if (IndexDefinitions$Companion_instance === null) {
      new IndexDefinitions$Companion();
    }
    return IndexDefinitions$Companion_instance;
  }
  IndexDefinitions.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'IndexDefinitions',
    interfaces: []
  };
  function Indexed() {
  }
  Indexed.$metadata$ = {
    kind: Kotlin.Kind.INTERFACE,
    simpleName: 'Indexed',
    interfaces: []
  };
  function IndexEnum(name, ordinal, indexClass) {
    Enum.call(this);
    this.indexClass = indexClass;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function IndexEnum_initFields() {
    IndexEnum_initFields = function () {
    };
    IndexEnum$NONE_instance = new IndexEnum('NONE', 0, Kotlin.getKClass(Any));
    IndexEnum$FixedStatusIndex_instance = new IndexEnum('FixedStatusIndex', 1, Kotlin.getKClass(FixedStatus));
    IndexEnum$IntroDate_instance = new IndexEnum('IntroDate', 2, Kotlin.getKClass(Date));
    IndexEnum$LastUpdatedDate_instance = new IndexEnum('LastUpdatedDate', 3, Kotlin.getKClass(Date));
    IndexEnum$LastMajorStatus_instance = new IndexEnum('LastMajorStatus', 4, Kotlin.getKClass(MajorStatus));
  }
  var IndexEnum$NONE_instance;
  function IndexEnum$NONE_getInstance() {
    IndexEnum_initFields();
    return IndexEnum$NONE_instance;
  }
  var IndexEnum$FixedStatusIndex_instance;
  function IndexEnum$FixedStatusIndex_getInstance() {
    IndexEnum_initFields();
    return IndexEnum$FixedStatusIndex_instance;
  }
  var IndexEnum$IntroDate_instance;
  function IndexEnum$IntroDate_getInstance() {
    IndexEnum_initFields();
    return IndexEnum$IntroDate_instance;
  }
  var IndexEnum$LastUpdatedDate_instance;
  function IndexEnum$LastUpdatedDate_getInstance() {
    IndexEnum_initFields();
    return IndexEnum$LastUpdatedDate_instance;
  }
  var IndexEnum$LastMajorStatus_instance;
  function IndexEnum$LastMajorStatus_getInstance() {
    IndexEnum_initFields();
    return IndexEnum$LastMajorStatus_instance;
  }
  IndexEnum.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'IndexEnum',
    interfaces: [Enum]
  };
  function IndexEnum$values() {
    return [IndexEnum$NONE_getInstance(), IndexEnum$FixedStatusIndex_getInstance(), IndexEnum$IntroDate_getInstance(), IndexEnum$LastUpdatedDate_getInstance(), IndexEnum$LastMajorStatus_getInstance()];
  }
  IndexEnum.values = IndexEnum$values;
  function IndexEnum$valueOf(name) {
    switch (name) {
      case 'NONE':
        return IndexEnum$NONE_getInstance();
      case 'FixedStatusIndex':
        return IndexEnum$FixedStatusIndex_getInstance();
      case 'IntroDate':
        return IndexEnum$IntroDate_getInstance();
      case 'LastUpdatedDate':
        return IndexEnum$LastUpdatedDate_getInstance();
      case 'LastMajorStatus':
        return IndexEnum$LastMajorStatus_getInstance();
      default:Kotlin.throwISE('No enum constant bz.stew.bracken.model.index.IndexEnum.' + name);
    }
  }
  IndexEnum.valueOf_61zpoe$ = IndexEnum$valueOf;
  function IndexOperation(name, ordinal) {
    Enum.call(this);
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function IndexOperation_initFields() {
    IndexOperation_initFields = function () {
    };
    IndexOperation$GreaterThanOrEqual_instance = new IndexOperation('GreaterThanOrEqual', 0);
    IndexOperation$LessThanOrEqual_instance = new IndexOperation('LessThanOrEqual', 1);
  }
  var IndexOperation$GreaterThanOrEqual_instance;
  function IndexOperation$GreaterThanOrEqual_getInstance() {
    IndexOperation_initFields();
    return IndexOperation$GreaterThanOrEqual_instance;
  }
  var IndexOperation$LessThanOrEqual_instance;
  function IndexOperation$LessThanOrEqual_getInstance() {
    IndexOperation_initFields();
    return IndexOperation$LessThanOrEqual_instance;
  }
  IndexOperation.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'IndexOperation',
    interfaces: [Enum]
  };
  function IndexOperation$values() {
    return [IndexOperation$GreaterThanOrEqual_getInstance(), IndexOperation$LessThanOrEqual_getInstance()];
  }
  IndexOperation.values = IndexOperation$values;
  function IndexOperation$valueOf(name) {
    switch (name) {
      case 'GreaterThanOrEqual':
        return IndexOperation$GreaterThanOrEqual_getInstance();
      case 'LessThanOrEqual':
        return IndexOperation$LessThanOrEqual_getInstance();
      default:Kotlin.throwISE('No enum constant bz.stew.bracken.model.index.IndexOperation.' + name);
    }
  }
  IndexOperation.valueOf_61zpoe$ = IndexOperation$valueOf;
  function MappedIndex(allKey) {
    this.allKey_77g0r1$_0 = allKey;
    this.forwardMap = Kotlin.kotlin.collections.LinkedHashMap_init_q3lmfv$();
    this.reverseMap = Kotlin.kotlin.collections.LinkedHashMap_init_q3lmfv$();
  }
  MappedIndex.prototype.input_xwzc9p$ = function (key, instance) {
    var insts = this.forwardMap.get_11rb$(key);
    if (insts == null) {
      insts = Kotlin.kotlin.collections.LinkedHashSet_init_287e2$();
    }
    if (!insts.contains_11rb$(instance)) {
      insts.add_11rb$(instance);
    }
    this.forwardMap.put_xwzc9p$(key, insts);
    this.reverseMap.put_xwzc9p$(instance, key);
  };
  MappedIndex.prototype.instancesWith_11rb$ = function (c) {
    var tmp$;
    if (Kotlin.equals(c, this.allKey_77g0r1$_0)) {
      return toList(this.reverseMap.keys);
    }
    var insts = this.forwardMap.get_11rb$(c);
    return (tmp$ = insts != null ? toList(insts) : null) != null ? tmp$ : emptyList_0();
  };
  MappedIndex.prototype.allKeys = function () {
    return union(this.forwardMap.keys, Kotlin.kotlin.collections.emptySet_287e2$());
  };
  MappedIndex.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'MappedIndex',
    interfaces: []
  };
  function NumericDoubleAbstractMappedIndex() {
    AbstractMappedIndex.call(this, null);
    this.minKeyCached_at6c8n$_0 = null;
    this.maxKeyCached_at6c8n$_0 = null;
  }
  function NumericDoubleAbstractMappedIndex$instancesByOperator$lambda(closure$operator, closure$c, this$NumericDoubleAbstractMappedIndex) {
    return function () {
      return closure$operator + ' comparing ' + closure$c + ' in map ' + '\n' + '\t' + '[[[' + this$NumericDoubleAbstractMappedIndex.forwardMap + ']]]';
    };
  }
  function NumericDoubleAbstractMappedIndex$instancesByOperator$lambda$lambda(closure$c, closure$it) {
    return function () {
      return 'Comparing ' + closure$c + ' to ' + closure$it.key;
    };
  }
  function NumericDoubleAbstractMappedIndex$instancesByOperator$lambda$lambda_0(closure$it) {
    return function () {
      return '--> PASSED @ ' + closure$it.key;
    };
  }
  function NumericDoubleAbstractMappedIndex$instancesByOperator$lambda$lambda_1(closure$it) {
    return function () {
      return '--> FAILED @ ' + closure$it.key;
    };
  }
  function NumericDoubleAbstractMappedIndex$instancesByOperator$lambda$lambda_2(closure$c, closure$it) {
    return function () {
      return 'Comparing ' + closure$c + ' to ' + closure$it.key;
    };
  }
  function NumericDoubleAbstractMappedIndex$instancesByOperator$lambda$lambda_3(closure$it) {
    return function () {
      return '--> PASSED @ ' + closure$it.key;
    };
  }
  function NumericDoubleAbstractMappedIndex$instancesByOperator$lambda$lambda_4(closure$it) {
    return function () {
      return '--> FAILED @ ' + closure$it.key;
    };
  }
  function NumericDoubleAbstractMappedIndex$instancesByOperator$lambda_0(closure$out) {
    return function () {
      return 'OUT == [[[' + '\n' + '\t' + closure$out + ']]]';
    };
  }
  NumericDoubleAbstractMappedIndex.prototype.instancesByOperator_dggtll$ = function (operator, c) {
    var tmp$;
    Log$LogCompanion_getInstance().debug_h4ejuu$(NumericDoubleAbstractMappedIndex$instancesByOperator$lambda(operator, c, this));
    if (Kotlin.equals(operator, IndexOperation$GreaterThanOrEqual_getInstance())) {
      var $receiver = this.forwardMap;
      var destination = Kotlin.kotlin.collections.ArrayList_init_ww73n8$();
      var tmp$_0;
      tmp$_0 = $receiver.entries.iterator();
      while (tmp$_0.hasNext()) {
        var element = tmp$_0.next();
        var transform$result;
        Log$LogCompanion_getInstance().debug_h4ejuu$(NumericDoubleAbstractMappedIndex$instancesByOperator$lambda$lambda(c, element));
        if (element.key - c >= 0.0) {
          Log$LogCompanion_getInstance().debug_h4ejuu$(NumericDoubleAbstractMappedIndex$instancesByOperator$lambda$lambda_0(element));
          transform$result = element.value;
        }
         else {
          Log$LogCompanion_getInstance().debug_h4ejuu$(NumericDoubleAbstractMappedIndex$instancesByOperator$lambda$lambda_1(element));
          var emptyList_1 = emptyList_0();
          transform$result = emptyList_1;
        }
        var list = transform$result;
        Kotlin.kotlin.collections.addAll_ipc267$(destination, list);
      }
      tmp$ = destination;
    }
     else if (Kotlin.equals(operator, IndexOperation$LessThanOrEqual_getInstance())) {
      var $receiver_0 = this.forwardMap;
      var destination_0 = Kotlin.kotlin.collections.ArrayList_init_ww73n8$();
      var tmp$_1;
      tmp$_1 = $receiver_0.entries.iterator();
      while (tmp$_1.hasNext()) {
        var element_0 = tmp$_1.next();
        var transform$result_0;
        Log$LogCompanion_getInstance().debug_h4ejuu$(NumericDoubleAbstractMappedIndex$instancesByOperator$lambda$lambda_2(c, element_0));
        if (element_0.key - c <= 0.0) {
          Log$LogCompanion_getInstance().debug_h4ejuu$(NumericDoubleAbstractMappedIndex$instancesByOperator$lambda$lambda_3(element_0));
          transform$result_0 = element_0.value;
        }
         else {
          Log$LogCompanion_getInstance().debug_h4ejuu$(NumericDoubleAbstractMappedIndex$instancesByOperator$lambda$lambda_4(element_0));
          transform$result_0 = emptyList_0();
        }
        var list_0 = transform$result_0;
        Kotlin.kotlin.collections.addAll_ipc267$(destination_0, list_0);
      }
      tmp$ = destination_0;
    }
     else
      tmp$ = Kotlin.noWhenBranchMatched();
    var out = tmp$;
    Log$LogCompanion_getInstance().debug_h4ejuu$(NumericDoubleAbstractMappedIndex$instancesByOperator$lambda_0(out));
    return out;
  };
  NumericDoubleAbstractMappedIndex.prototype.compareTo_41hqm1$ = function (key, other) {
    return key - this.map_11rc$(other);
  };
  NumericDoubleAbstractMappedIndex.prototype.maxKey = function () {
    var tmp$, tmp$_0;
    if (this.maxKeyCached_at6c8n$_0 == null) {
      this.maxKeyCached_at6c8n$_0 = (tmp$ = max(this.forwardMap.keys)) != null ? tmp$ : DoubleCompanionObject.NaN;
    }
    return (tmp$_0 = this.maxKeyCached_at6c8n$_0) != null ? tmp$_0 : DoubleCompanionObject.NaN;
  };
  NumericDoubleAbstractMappedIndex.prototype.minKey = function () {
    var tmp$, tmp$_0;
    if (this.minKeyCached_at6c8n$_0 == null) {
      this.minKeyCached_at6c8n$_0 = (tmp$ = min(this.forwardMap.keys)) != null ? tmp$ : DoubleCompanionObject.NaN;
    }
    return (tmp$_0 = this.minKeyCached_at6c8n$_0) != null ? tmp$_0 : DoubleCompanionObject.NaN;
  };
  NumericDoubleAbstractMappedIndex.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'NumericDoubleAbstractMappedIndex',
    interfaces: [AbstractMappedIndex]
  };
  function EPTypeHelper(niceString) {
    this.niceString_0 = niceString;
    this.xmlName = replace(this.niceString_0.toUpperCase(), 32, 95);
    this.caps = this.xmlName;
    this.lowerCase = this.caps.toLowerCase();
  }
  EPTypeHelper.prototype.lowercaseName = function () {
    return this.lowerCase;
  };
  EPTypeHelper.prototype.capitalizedName = function () {
    return this.caps;
  };
  EPTypeHelper.prototype.niceFormat = function () {
    return this.niceString_0;
  };
  EPTypeHelper.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'EPTypeHelper',
    interfaces: []
  };
  function VisibleType() {
  }
  VisibleType.$metadata$ = {
    kind: Kotlin.Kind.INTERFACE,
    simpleName: 'VisibleType',
    interfaces: []
  };
  function Animation() {
    this.isRunning_r9y3p$_0 = false;
    this.playAnimationBackwards_r9y3p$_0 = false;
    this.duration_r9y3p$_0 = 300;
    this.element = null;
    this.cancellable_r9y3p$_0 = true;
    this.onStartCallbacks_r9y3p$_0 = ArrayList_init();
    this.onEndCallbacks_r9y3p$_0 = ArrayList_init();
    this.currentRunId_r9y3p$_0 = 0;
  }
  Animation.prototype.run = function () {
    this.runAnimation_r9y3p$_0();
  };
  Animation.prototype.run_sxdzfv$ = function (duration, element) {
    this.duration_r9y3p$_0 = duration;
    this.element = element;
    this.runAnimation_r9y3p$_0();
  };
  Animation.prototype.onStart = function () {
    var tmp$;
    tmp$ = this.onStartCallbacks_r9y3p$_0.iterator();
    while (tmp$.hasNext()) {
      var element = tmp$.next();
      element();
    }
    this.onUpdate_14dthe$(this.playAnimationBackwards_r9y3p$_0 ? 1.0 : 0.0);
  };
  Animation.prototype.onComplete = function () {
    this.onUpdate_14dthe$(this.playAnimationBackwards_r9y3p$_0 ? 0.0 : 1.0);
    this.isRunning_r9y3p$_0 = false;
    var tmp$;
    tmp$ = this.onEndCallbacks_r9y3p$_0.iterator();
    while (tmp$.hasNext()) {
      var element = tmp$.next();
      element();
    }
  };
  Animation.prototype.cancel = function () {
    this.isRunning_r9y3p$_0 = false;
  };
  Animation.prototype.getDuration = function () {
    return this.duration_r9y3p$_0;
  };
  Animation.prototype.setDuration_za3lpa$ = function (duration) {
    if (duration < 0) {
      throw new IllegalArgumentException();
    }
    this.duration_r9y3p$_0 = duration;
  };
  Animation.prototype.getPlayBackwards = function () {
    return this.playAnimationBackwards_r9y3p$_0;
  };
  Animation.prototype.setPlayBackwards_6taknv$ = function (playAnimationBackwards) {
    this.playAnimationBackwards_r9y3p$_0 = playAnimationBackwards;
  };
  Animation.prototype.getElement = function () {
    return this.element;
  };
  Animation.prototype.setElement_y4uc7f$ = function (element) {
    this.element = element;
  };
  Animation.prototype.setCancellable = function () {
    return this.cancellable_r9y3p$_0;
  };
  Animation.prototype.setCancellable_6taknv$ = function (cancellable) {
    this.cancellable_r9y3p$_0 = cancellable;
  };
  Animation.prototype.addOnStartCallback_o14v8n$ = function (callback) {
    this.onStartCallbacks_r9y3p$_0.add_11rb$(callback);
  };
  Animation.prototype.removeOnStartCallback_o14v8n$ = function (callback) {
    this.onStartCallbacks_r9y3p$_0.remove_11rb$(callback);
  };
  Animation.prototype.clearOnStartCallbacks = function () {
    this.onStartCallbacks_r9y3p$_0.clear();
  };
  Animation.prototype.addOnEndCallback_o14v8n$ = function (callback) {
    this.onEndCallbacks_r9y3p$_0.add_11rb$(callback);
  };
  Animation.prototype.removeOnEndCallback_o14v8n$ = function (callback) {
    this.onEndCallbacks_r9y3p$_0.remove_11rb$(callback);
  };
  Animation.prototype.clearOnEndCallbacks = function () {
    this.onEndCallbacks_r9y3p$_0.clear();
  };
  Animation.prototype.rescale_1lq62i$ = function (x, originalMin, originalMax, newMin, newMax) {
    return (x - originalMin) * (newMax - newMin) / (originalMax - originalMin) + newMin;
  };
  Animation.prototype.runAnimation_r9y3p$_0 = function () {
    if (this.isRunning_r9y3p$_0) {
      if (this.cancellable_r9y3p$_0)
        this.cancel();
      else
        return;
    }
    this.isRunning_r9y3p$_0 = true;
    this.currentRunId_r9y3p$_0 = this.currentRunId_r9y3p$_0 + 1 | 0;
    this.onStart();
    if (this.duration_r9y3p$_0 > 0) {
      this.requestNextAnimationFrame_yktxzz$_0(this.currentRunId_r9y3p$_0, (new Date()).getTime(), this.duration_r9y3p$_0);
    }
     else {
      this.onComplete();
    }
  };
  function Animation$requestNextAnimationFrame$lambda(this$Animation, closure$runId, closure$startTime, closure$duration, closure$easingInOut) {
    return function (timestamp) {
      if (this$Animation.isRunning_r9y3p$_0 && this$Animation.currentRunId_r9y3p$_0 === closure$runId) {
        var elapsedTime = (new Date()).getTime() - closure$startTime;
        if (closure$duration > elapsedTime) {
          var progressNormal = !closure$easingInOut ? elapsedTime / closure$duration : Math$Ease_getInstance().easeInOutQuad_6y0v78$((new Date()).getTime(), closure$startTime, elapsedTime, closure$duration);
          this$Animation.onUpdate_14dthe$(this$Animation.playAnimationBackwards_r9y3p$_0 ? 1.0 - progressNormal : progressNormal);
          this$Animation.requestNextAnimationFrame_yktxzz$_0(closure$runId, closure$startTime, closure$duration);
        }
         else {
          this$Animation.onComplete();
        }
      }
    };
  }
  Animation.prototype.requestNextAnimationFrame_yktxzz$_0 = function (runId, startTime, duration) {
    var easingInOut = false;
    window.requestAnimationFrame(Animation$requestNextAnimationFrame$lambda(this, runId, startTime, duration, easingInOut));
  };
  Animation.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'Animation',
    interfaces: []
  };
  function LogLevel(name, ordinal) {
    Enum.call(this);
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function LogLevel_initFields() {
    LogLevel_initFields = function () {
    };
    LogLevel$SILENT_instance = new LogLevel('SILENT', 0);
    LogLevel$ERROR_instance = new LogLevel('ERROR', 1);
    LogLevel$WARNING_instance = new LogLevel('WARNING', 2);
    LogLevel$INFO_instance = new LogLevel('INFO', 3);
    LogLevel$DEBUG_instance = new LogLevel('DEBUG', 4);
  }
  var LogLevel$SILENT_instance;
  function LogLevel$SILENT_getInstance() {
    LogLevel_initFields();
    return LogLevel$SILENT_instance;
  }
  var LogLevel$ERROR_instance;
  function LogLevel$ERROR_getInstance() {
    LogLevel_initFields();
    return LogLevel$ERROR_instance;
  }
  var LogLevel$WARNING_instance;
  function LogLevel$WARNING_getInstance() {
    LogLevel_initFields();
    return LogLevel$WARNING_instance;
  }
  var LogLevel$INFO_instance;
  function LogLevel$INFO_getInstance() {
    LogLevel_initFields();
    return LogLevel$INFO_instance;
  }
  var LogLevel$DEBUG_instance;
  function LogLevel$DEBUG_getInstance() {
    LogLevel_initFields();
    return LogLevel$DEBUG_instance;
  }
  LogLevel.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'LogLevel',
    interfaces: [Enum]
  };
  function LogLevel$values() {
    return [LogLevel$SILENT_getInstance(), LogLevel$ERROR_getInstance(), LogLevel$WARNING_getInstance(), LogLevel$INFO_getInstance(), LogLevel$DEBUG_getInstance()];
  }
  LogLevel.values = LogLevel$values;
  function LogLevel$valueOf(name) {
    switch (name) {
      case 'SILENT':
        return LogLevel$SILENT_getInstance();
      case 'ERROR':
        return LogLevel$ERROR_getInstance();
      case 'WARNING':
        return LogLevel$WARNING_getInstance();
      case 'INFO':
        return LogLevel$INFO_getInstance();
      case 'DEBUG':
        return LogLevel$DEBUG_getInstance();
      default:Kotlin.throwISE('No enum constant bz.stew.bracken.util.log.LogLevel.' + name);
    }
  }
  LogLevel.valueOf_61zpoe$ = LogLevel$valueOf;
  function Log() {
    Log$LogCompanion_getInstance();
    this.messages_0 = HashMap_init();
    this.logLevel = LogLevel$ERROR_getInstance();
    this.saveMessages = false;
  }
  function Log$LogCompanion() {
    Log$LogCompanion_instance = this;
  }
  Log$LogCompanion.prototype.getLogLevel = function () {
    return logs.logLevel;
  };
  Log$LogCompanion.prototype.setLogLevel_v1gg91$ = function (lvl) {
    logs.logLevel = lvl;
  };
  Log$LogCompanion.prototype.warning_61zpoe$ = function (s) {
    logs.logMessage_u02b1l$(LogLevel$WARNING_getInstance(), s);
  };
  Log$LogCompanion.prototype.debug_61zpoe$ = function (s) {
    logs.logMessage_u02b1l$(LogLevel$DEBUG_getInstance(), s);
  };
  Log$LogCompanion.prototype.error_61zpoe$ = function (s) {
    logs.logMessage_u02b1l$(LogLevel$ERROR_getInstance(), s);
  };
  Log$LogCompanion.prototype.info_61zpoe$ = function (s) {
    logs.logMessage_u02b1l$(LogLevel$INFO_getInstance(), s);
  };
  Log$LogCompanion.prototype.warning_h4ejuu$ = function (fn) {
    logs.logMessage_xkp3ep$(LogLevel$WARNING_getInstance(), fn);
  };
  Log$LogCompanion.prototype.debug_h4ejuu$ = function (fn) {
    logs.logMessage_xkp3ep$(LogLevel$DEBUG_getInstance(), fn);
  };
  Log$LogCompanion.prototype.error_h4ejuu$ = function (fn) {
    logs.logMessage_xkp3ep$(LogLevel$ERROR_getInstance(), fn);
  };
  Log$LogCompanion.prototype.info_h4ejuu$ = function (fn) {
    logs.logMessage_xkp3ep$(LogLevel$INFO_getInstance(), fn);
  };
  Log$LogCompanion.$metadata$ = {
    kind: Kotlin.Kind.OBJECT,
    simpleName: 'LogCompanion',
    interfaces: []
  };
  var Log$LogCompanion_instance = null;
  function Log$LogCompanion_getInstance() {
    if (Log$LogCompanion_instance === null) {
      new Log$LogCompanion();
    }
    return Log$LogCompanion_instance;
  }
  Log.prototype.logMessage_u02b1l$ = function (msgLevel, msg) {
    this.saveMessage_0(msgLevel, msg);
    if (this.logLevel !== LogLevel$SILENT_getInstance() && this.logLevel.ordinal >= msgLevel.ordinal) {
      println('Warning: ' + msg);
    }
  };
  Log.prototype.logMessage_xkp3ep$ = function (msgLevel, msg) {
    this.saveMessage_1(msgLevel, msg);
    if (this.logLevel !== LogLevel$SILENT_getInstance() && this.logLevel.ordinal >= msgLevel.ordinal) {
      println('Warning: ' + msg());
    }
  };
  Log.prototype.saveMessage_1 = function (msgLevel, msg) {
    if (this.saveMessages) {
      this.saveMessage_0(msgLevel, msg());
    }
  };
  Log.prototype.saveMessage_0 = function (msgLevel, msg) {
    if (this.saveMessages) {
      var set_0 = logs.messages_0.get_11rb$(this.logLevel);
      if (set_0 == null) {
        set_0 = HashSet_init();
      }
      set_0.add_11rb$(msg);
      logs.messages_0.put_xwzc9p$(msgLevel, set_0);
    }
  };
  Log.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'Log',
    interfaces: []
  };
  var logs;
  function UIFormatter() {
    UIFormatter$DateCompanion_getInstance();
  }
  function UIFormatter$DateCompanion() {
    UIFormatter$DateCompanion_instance = this;
  }
  UIFormatter$DateCompanion.prototype.prettyDate_qjzqsm$ = function (date) {
    var tmp$, tmp$_0, tmp$_1;
    var delta = Math.round(((new Date()).getTime() - (typeof (tmp$ = date.getTime()) === 'number' ? tmp$ : Kotlin.throwCCE())) / 1000);
    var isFuture = delta < 0;
    var minute = 60;
    var hour = minute * 60 | 0;
    var day = hour * 24 | 0;
    var week = day * 7 | 0;
    var month = week * 4 | 0;
    var fuzzy;
    if (!isFuture) {
      if (delta < 30)
        tmp$_0 = 'just now';
      else if (delta < minute)
        tmp$_0 = delta.toString() + ' seconds ago';
      else if (delta < (2 * minute | 0))
        tmp$_0 = 'a minute ago';
      else if (delta < hour)
        tmp$_0 = Math.floor(delta / minute | 0).toString() + ' minutes ago';
      else if (Math.floor(delta / hour | 0) === 1)
        tmp$_0 = '1 hour ago';
      else if (delta < day)
        tmp$_0 = Math.floor(delta / hour | 0).toString() + ' hours ago';
      else if (delta < (day * 2 | 0))
        tmp$_0 = 'yesterday';
      else if (delta < (2 * week | 0))
        tmp$_0 = Math.floor(delta / day | 0).toString() + ' days ago';
      else if (delta < month)
        tmp$_0 = Math.floor(delta / week | 0).toString() + ' weeks ago';
      else
        tmp$_0 = 'over a month ago';
      fuzzy = tmp$_0;
    }
     else {
      if (delta > -30)
        tmp$_1 = 'very recently';
      else if (delta > minute)
        tmp$_1 = 'in ' + delta.toString() + ' seconds';
      else if (delta > (2 * minute | 0))
        tmp$_1 = 'in a minute';
      else if (delta > hour)
        tmp$_1 = 'in ' + Math.floor(delta / minute | 0).toString() + ' minutes';
      else if (Math.floor(delta / hour | 0) === -1)
        tmp$_1 = 'in 1 hour';
      else if (delta > day)
        tmp$_1 = 'in ' + Math.floor(delta / hour | 0).toString() + ' hours';
      else if (delta > (day * 2 | 0))
        tmp$_1 = 'tomorrow';
      else
        tmp$_1 = 'in a while';
      fuzzy = tmp$_1;
    }
    return fuzzy;
  };
  UIFormatter$DateCompanion.$metadata$ = {
    kind: Kotlin.Kind.OBJECT,
    simpleName: 'DateCompanion',
    interfaces: []
  };
  var UIFormatter$DateCompanion_instance = null;
  function UIFormatter$DateCompanion_getInstance() {
    if (UIFormatter$DateCompanion_instance === null) {
      new UIFormatter$DateCompanion();
    }
    return UIFormatter$DateCompanion_instance;
  }
  UIFormatter.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'UIFormatter',
    interfaces: []
  };
  function BillView(rootElmtStr) {
    View.call(this, rootElmtStr);
    this.COUNT_TEXT_HTML_SELECTOR = new HtmlSelector(Identifier$ID_getInstance(), 'nav-bar-billCount');
    this.OPEN_SPEED = 250;
    this.HIDE_SPEED = 200;
    this.OPEN_HEIGHT = 30;
    this.OPEN_HEIGHT_UNITS = 'rem';
    this.activeCell = null;
    this.internalBillId = 0;
    this.billViews_0 = Kotlin.kotlin.collections.LinkedHashMap_init_q3lmfv$();
    this.SKIP_PROFILE_IMG = true;
    this.visibleBills = Kotlin.kotlin.collections.LinkedHashSet_init_287e2$();
  }
  BillView.prototype.initiateModelData_err50$ = function (bills) {
    var tmp$;
    tmp$ = bills.iterator();
    while (tmp$.hasNext()) {
      var b = tmp$.next();
      this.billViews_0.put_xwzc9p$(b.uniqueId, new BillViewItem(b));
    }
  };
  BillView.prototype.loadStatusFilter_l3suxh$ = function (filterEntry, allStatus) {
    var tmp$;
    var parent = this.getElement_q0rfmm$(filterEntry.htmlSelector());
    tmp$ = allStatus.iterator();
    while (tmp$.hasNext()) {
      var fs = tmp$.next();
      var eco = mapOf(new Pair('value', fs.ordinal.toString()));
      parent.appendChild(Form$Option_getInstance().generateHtml_mvjluj$(fs.name, eco));
    }
  };
  BillView.prototype.loadMajorStatusFilter_qj2vly$ = function (filterEntry, allMajorStatus) {
    var tmp$;
    var parent = this.getElement_q0rfmm$(filterEntry.htmlSelector());
    tmp$ = allMajorStatus.iterator();
    while (tmp$.hasNext()) {
      var fs = tmp$.next();
      var eco = mapOf(new Pair('value', fs.ordinal.toString()));
      parent.appendChild(Form$Option_getInstance().generateHtml_mvjluj$(fs.niceFormat(), eco));
    }
  };
  BillView.prototype.updateBillCountText_za3lpa$ = function (billCount) {
    get($(this.COUNT_TEXT_HTML_SELECTOR.text()), 0).innerHTML = 'Showing ' + billCount + ' bills';
  };
  function BillView$showSelectedBills$lambda(closure$bills) {
    return function () {
      return 'Showing #' + closure$bills.size + ' bills';
    };
  }
  BillView.prototype.showSelectedBills_815ehw$ = function (bills) {
    var tmp$, tmp$_0;
    this.visibleBills.clear();
    tmp$ = bills.iterator();
    while (tmp$.hasNext()) {
      var b = tmp$.next();
      var bv = this.billViews_0.get_11rb$(b.uniqueId);
      if (bv != null) {
        this.visibleBills.add_11rb$(bv);
      }
    }
    Log$LogCompanion_getInstance().debug_h4ejuu$(BillView$showSelectedBills$lambda(bills));
    this.updateBillCountText_za3lpa$(bills.size);
    var remainingBills = toMutableMap(this.billViews_0);
    tmp$_0 = this.visibleBills.iterator();
    while (tmp$_0.hasNext()) {
      var bv_0 = tmp$_0.next();
      this.getJq_q0rfmm$(bv_0.selector()).addClass('billVisible').removeClass('billHidden');
      remainingBills.remove_11rb$(bv_0.billData.uniqueId);
    }
    var tmp$_1;
    tmp$_1 = remainingBills.entries.iterator();
    while (tmp$_1.hasNext()) {
      var element = tmp$_1.next();
      this.getJq_q0rfmm$(element.value.selector()).addClass('billHidden').removeClass('billVisible');
    }
    hide_1($('.billHidden'), 'slow');
    $('.billVisible').show('slow');
  };
  function BillView$generateAndDisplayAllBills$lambda(closure$sortedList) {
    return function () {
      return 'Showing #' + closure$sortedList.size + ' bills';
    };
  }
  BillView.prototype.generateAndDisplayAllBills = function () {
    var tmp$;
    var billListJQ = this.getJq_q0rfmm$(this.rootElementSelector);
    var sortedList = sorted(this.billViews_0.values);
    this.visibleBills.clear();
    Log$LogCompanion_getInstance().debug_h4ejuu$(BillView$generateAndDisplayAllBills$lambda(sortedList));
    this.updateBillCountText_za3lpa$(sortedList.size);
    tmp$ = sortedList.iterator();
    while (tmp$.hasNext()) {
      var i = tmp$.next();
      if (Kotlin.isType(i, BillViewItem)) {
        try {
          this.generateBillView_qco9ok$(i, billListJQ);
          this.initiateBill_42na2m$(i);
          this.visibleBills.add_11rb$(i);
        }
         catch (e) {
          if (Kotlin.isType(e, Throwable)) {
            println(e.toString());
          }
           else
            throw e;
        }
      }
    }
  };
  function BillView$makeAnimation$ObjectLiteral(closure$position, closure$units) {
    this.closure$position = closure$position;
    this.closure$units = closure$units;
    Animation.call(this);
  }
  BillView$makeAnimation$ObjectLiteral.prototype.onUpdate_14dthe$ = function (progress) {
    var tmp$;
    ((tmp$ = this.element) != null ? tmp$ : Kotlin.throwNPE()).style.marginBottom = (progress * this.closure$position).toString() + this.closure$units;
  };
  BillView$makeAnimation$ObjectLiteral.prototype.onComplete = function () {
    Animation.prototype.onComplete.call(this);
  };
  BillView$makeAnimation$ObjectLiteral.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    interfaces: [Animation]
  };
  BillView.prototype.makeAnimation_0 = function (position, units, backwards) {
    if (backwards === void 0)
      backwards = false;
    var ani = new BillView$makeAnimation$ObjectLiteral(position, units);
    ani.setDuration_za3lpa$(this.OPEN_SPEED);
    ani.setPlayBackwards_6taknv$(backwards);
    return ani;
  };
  BillView.prototype.makeHtmlCellActive_lt8gi4$ = function (bill) {
    var active = this.activeCell;
    if (active != null) {
      var aniOpen = this.makeAnimation_0(this.OPEN_HEIGHT, this.OPEN_HEIGHT_UNITS, true);
      aniOpen.run_sxdzfv$(this.OPEN_SPEED, active);
      hide_0($(active).children('.billExpanded'), this.HIDE_SPEED);
      if (Kotlin.equals(this.activeCell, bill)) {
        this.activeCell = null;
        return;
      }
    }
    this.activeCell = bill;
    var child = $(bill).children('.billExpanded');
    child.css('transform', 'translateX(-' + Kotlin.toString(elementFixedOffset(document, bill).x) + 'px)');
    child.show(this.OPEN_SPEED);
    var aniOpen_0 = this.makeAnimation_0(this.OPEN_HEIGHT, this.OPEN_HEIGHT_UNITS);
    aniOpen_0.run_sxdzfv$(this.OPEN_SPEED, bill);
  };
  BillView.prototype.makeCellActive_q0rfmm$ = function (billSelector) {
    var tmp$;
    var jqd = $(billSelector.text());
    this.makeHtmlCellActive_lt8gi4$(Kotlin.isType(tmp$ = jqd[0], HTMLElement) ? tmp$ : Kotlin.throwCCE());
  };
  function BillView$generateBillView$lambda(closure$billView) {
    return function (it) {
      it != null ? (it.innerHTML = closure$billView.shortLabel()) : null;
    };
  }
  function BillView$generateBillView$lambda_0(closure$sponsorName) {
    return function (it) {
      it != null ? (it.innerHTML = closure$sponsorName) : null;
    };
  }
  function BillView$generateBillView$lambda_1(closure$name) {
    return function (it) {
      it != null ? (it.innerHTML = closure$name) : null;
    };
  }
  function BillView$generateBillView$lambda_2(closure$statusLabel) {
    return function (it) {
      it != null ? (it.innerHTML = 'Status: ' + closure$statusLabel) : null;
    };
  }
  function BillView$generateBillView$lambda_3(closure$introDate) {
    return function (it) {
      it != null ? (it.innerHTML = closure$introDate) : null;
    };
  }
  function BillView$generateBillView$lambda_4(closure$statusDescr) {
    return function (it) {
      it != null ? (it.innerHTML = closure$statusDescr) : null;
    };
  }
  function BillView$generateBillView$lambda$lambda(closure$link) {
    return function ($receiver) {
      $receiver.setAttribute('href', closure$link);
      $receiver.innerHTML = 'Link to bd';
    };
  }
  function BillView$generateBillView$lambda_5(closure$link) {
    return function (it) {
      var linkElmt = createElement(document, 'a', BillView$generateBillView$lambda$lambda(closure$link));
      it != null ? it.appendChild(linkElmt) : null;
    };
  }
  function BillView$generateBillView$lambda$lambda_0(closure$newSelector) {
    return function (it) {
      it != null ? it.setAttribute('href', closure$newSelector.text()) : null;
    };
  }
  function BillView$generateBillView$lambda$lambda_1(closure$newSelector) {
    return function (it) {
      it.id = closure$newSelector.suffix();
    };
  }
  function BillView$generateBillView$lambda_6(closure$billSponsorProfileImg) {
    return function (it) {
      it != null ? it.setAttribute('src', closure$billSponsorProfileImg) : null;
    };
  }
  BillView.prototype.generateBillView_qco9ok$ = function (billView, parentJq) {
    var bd = billView.billData;
    this.internalBillId = this.internalBillId + 1 | 0;
    var billId = billView.selector();
    var name = bd.title;
    var statusDescription = bd.status.description;
    var sponsorName = bd.sponsor.getName();
    var introDate = UIFormatter$DateCompanion_getInstance().prettyDate_qjzqsm$(bd.intro_date);
    var status = bd.status;
    var statusLabel = status.label;
    var statusDescr = status.description;
    var link = bd.link;
    var congress = bd.congress;
    var partyNameClass = bd.sponsor.getParty().lowercaseName();
    var billResolType = bd.bill_resolution_type;
    var billType = bd.bill_type;
    var billSponsorProfileImg = billView.sponsorImageUrl();
    var view = this;
    var billJq = this.htmlGen.buildElement_61zpoe$('bill');
    var billHtml = get(billJq, 0);
    addClass(billHtml, [partyNameClass]);
    parentJq.append(billJq);
    hide(billJq);
    billId.addToJqElement_jlc00i$(billJq);
    eachChildClass(billHtml, 'billTitle', BillView$generateBillView$lambda(billView));
    eachChildClass(billHtml, 'billSponsor', BillView$generateBillView$lambda_0(sponsorName));
    eachChildClass(billHtml, 'billDescription', BillView$generateBillView$lambda_1(name));
    eachChildClass(billHtml, 'billStatus', BillView$generateBillView$lambda_2(statusLabel));
    eachChildClass(billHtml, 'billDate', BillView$generateBillView$lambda_3(introDate));
    eachChildClass(billHtml, 'billStatusDescription', BillView$generateBillView$lambda_4(statusDescr));
    eachChildClass(billHtml, 'billLink', BillView$generateBillView$lambda_5(link));
    var $receiver = new IntRange(0, 3);
    var destination = Kotlin.kotlin.collections.ArrayList_init_ww73n8$(Kotlin.kotlin.collections.collectionSizeOrDefault_ba2ldo$($receiver, 10));
    var tmp$;
    tmp$ = $receiver.iterator();
    while (tmp$.hasNext()) {
      var item = tmp$.next();
      destination.add_11rb$('bill-exp-nav-tab' + Kotlin.toString(item));
    }
    var tmp$_0;
    tmp$_0 = destination.iterator();
    while (tmp$_0.hasNext()) {
      var element = tmp$_0.next();
      var newSelector = new HtmlSelector(Identifier$ID_getInstance(), element + '-' + billId.suffix());
      eachChildClass(billHtml, element, BillView$generateBillView$lambda$lambda_0(newSelector));
      eachChildId(billHtml, element, BillView$generateBillView$lambda$lambda_1(newSelector));
    }
    if (!this.SKIP_PROFILE_IMG) {
      eachChildClass(billHtml, 'billExpandedSponsorImg', BillView$generateBillView$lambda_6(billSponsorProfileImg));
    }
    return billHtml;
  };
  function BillView$initiateBill$lambda(closure$view, closure$billSelector) {
    return function (e) {
      e.stopImmediatePropagation();
      e.stopPropagation();
      e.preventDefault();
      closure$view.makeCellActive_q0rfmm$(closure$billSelector);
    };
  }
  BillView.prototype.initiateBill_42na2m$ = function (bill) {
    var billSelector = bill.selector();
    var billJq = $(billSelector.text());
    var billElmt = get(billJq, 0);
    var view = this;
    var clickHeader = $(billJq).children('.billGridContent');
    get(clickHeader, 0).onclick = BillView$initiateBill$lambda(view, billSelector);
    billJq.fadeIn('slow');
  };
  BillView.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'BillView',
    interfaces: [View]
  };
  function Form(name, ordinal) {
    Enum.call(this);
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function Form_initFields() {
    Form_initFields = function () {
    };
    new Form$Option();
  }
  function Form$Option() {
    Form$Option_instance = this;
    Form.call(this, 'Option', 0);
  }
  Form$Option.prototype.generateHtml_mvjluj$ = function (innerHtml, options) {
    var tmp$;
    var out = document.createElement('option');
    tmp$ = options.entries.iterator();
    while (tmp$.hasNext()) {
      var pair = tmp$.next();
      out.setAttribute(pair.key, pair.value);
    }
    out.innerHTML = innerHtml;
    return out;
  };
  Form$Option.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'Option',
    interfaces: [Form]
  };
  var Form$Option_instance = null;
  function Form$Option_getInstance() {
    Form_initFields();
    return Form$Option_instance;
  }
  Form.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'Form',
    interfaces: [Enum]
  };
  function Form$values() {
    return [Form$Option_getInstance()];
  }
  Form.values = Form$values;
  function Form$valueOf(name) {
    switch (name) {
      case 'Option':
        return Form$Option_getInstance();
      default:Kotlin.throwISE('No enum constant bz.stew.bracken.view.html.Form.' + name);
    }
  }
  Form.valueOf_61zpoe$ = Form$valueOf;
  function Identifier(name, ordinal, prefix) {
    Enum.call(this);
    this.prefix_jg74d6$_0 = prefix;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function Identifier_initFields() {
    Identifier_initFields = function () {
    };
    Identifier$ID_instance = new Identifier('ID', 0, '#');
    Identifier$CLASS_instance = new Identifier('CLASS', 1, '.');
    Identifier$TAG_instance = new Identifier('TAG', 2, '');
  }
  var Identifier$ID_instance;
  function Identifier$ID_getInstance() {
    Identifier_initFields();
    return Identifier$ID_instance;
  }
  var Identifier$CLASS_instance;
  function Identifier$CLASS_getInstance() {
    Identifier_initFields();
    return Identifier$CLASS_instance;
  }
  var Identifier$TAG_instance;
  function Identifier$TAG_getInstance() {
    Identifier_initFields();
    return Identifier$TAG_instance;
  }
  Identifier.prototype.getPrefix = function () {
    return this.prefix_jg74d6$_0;
  };
  Identifier.prototype.toString = function () {
    return 'HtmlIdentifier [' + this.name + ']';
  };
  Identifier.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'Identifier',
    interfaces: [Enum]
  };
  function Identifier$values() {
    return [Identifier$ID_getInstance(), Identifier$CLASS_getInstance(), Identifier$TAG_getInstance()];
  }
  Identifier.values = Identifier$values;
  function Identifier$valueOf(name) {
    switch (name) {
      case 'ID':
        return Identifier$ID_getInstance();
      case 'CLASS':
        return Identifier$CLASS_getInstance();
      case 'TAG':
        return Identifier$TAG_getInstance();
      default:Kotlin.throwISE('No enum constant bz.stew.bracken.view.html.Identifier.' + name);
    }
  }
  Identifier.valueOf_61zpoe$ = Identifier$valueOf;
  function BillViewItem(billData) {
    this.billData = billData;
  }
  BillViewItem.prototype.shortLabel = function () {
    return this.billData.bill_type.shortLabel() + ' ' + Kotlin.toString(this.billData.number);
  };
  BillViewItem.prototype.sortBy = function () {
    return this.billData.number;
  };
  BillViewItem.prototype.selector = function () {
    return new HtmlSelector(Identifier$ID_getInstance(), 'bill' + this.billData.uniqueId.toString());
  };
  BillViewItem.prototype.compareTo_11rb$ = function (other) {
    return this.sortBy() - other.sortBy() | 0;
  };
  BillViewItem.prototype.sponsorImageUrl = function () {
    var twitterId = this.billData.sponsor.getTwitterId();
    return 'https://twitter.com/' + twitterId + '/profile_image?size=original';
  };
  BillViewItem.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'BillViewItem',
    interfaces: [ViewItem]
  };
  function ViewItem() {
  }
  ViewItem.$metadata$ = {
    kind: Kotlin.Kind.INTERFACE,
    simpleName: 'ViewItem',
    interfaces: [Comparable]
  };
  function BillFilters(name, ordinal, idxDef, predicate) {
    if (predicate === void 0)
      predicate = Kotlin.getCallableRef('identity', function (a, b) {
        return identity(a, b);
      });
    Enum.call(this);
    this.idxDef = idxDef;
    this.predicate = predicate;
    this.name$ = name;
    this.ordinal$ = ordinal;
    this.identifierCached_oe38wa$_0 = new HtmlSelector(Identifier$ID_getInstance(), 'billFilter-' + this.name.toLowerCase());
  }
  function BillFilters_initFields() {
    BillFilters_initFields = function () {
    };
    BillFilters$IDENTITY_instance = new BillFilters('IDENTITY', 0, IndexEnum$NONE_getInstance(), Kotlin.getCallableRef('identity', function (a, b) {
      return identity(a, b);
    }));
    BillFilters$PARTY_instance = new BillFilters('PARTY', 1, IndexEnum$NONE_getInstance(), Kotlin.getCallableRef('partyPredicate', function (bill, selectVal) {
      return partyPredicate(bill, selectVal);
    }));
    BillFilters$FIXEDSTATUS_instance = new BillFilters('FIXEDSTATUS', 2, IndexEnum$FixedStatusIndex_getInstance(), Kotlin.getCallableRef('statusPredicate', function (bill, selectVal) {
      return statusPredicate(bill, selectVal);
    }));
    BillFilters$DATEINTROSTART_instance = new BillFilters('DATEINTROSTART', 3, IndexEnum$IntroDate_getInstance());
    BillFilters$DATEINTROEND_instance = new BillFilters('DATEINTROEND', 4, IndexEnum$IntroDate_getInstance());
    BillFilters$LASTUPDATEDDATESTART_instance = new BillFilters('LASTUPDATEDDATESTART', 5, IndexEnum$LastUpdatedDate_getInstance());
    BillFilters$LASTUPDATEDDATEEND_instance = new BillFilters('LASTUPDATEDDATEEND', 6, IndexEnum$LastUpdatedDate_getInstance());
    BillFilters$LASTMAJORSTATUS_instance = new BillFilters('LASTMAJORSTATUS', 7, IndexEnum$LastMajorStatus_getInstance());
  }
  var BillFilters$IDENTITY_instance;
  function BillFilters$IDENTITY_getInstance() {
    BillFilters_initFields();
    return BillFilters$IDENTITY_instance;
  }
  var BillFilters$PARTY_instance;
  function BillFilters$PARTY_getInstance() {
    BillFilters_initFields();
    return BillFilters$PARTY_instance;
  }
  var BillFilters$FIXEDSTATUS_instance;
  function BillFilters$FIXEDSTATUS_getInstance() {
    BillFilters_initFields();
    return BillFilters$FIXEDSTATUS_instance;
  }
  var BillFilters$DATEINTROSTART_instance;
  function BillFilters$DATEINTROSTART_getInstance() {
    BillFilters_initFields();
    return BillFilters$DATEINTROSTART_instance;
  }
  var BillFilters$DATEINTROEND_instance;
  function BillFilters$DATEINTROEND_getInstance() {
    BillFilters_initFields();
    return BillFilters$DATEINTROEND_instance;
  }
  var BillFilters$LASTUPDATEDDATESTART_instance;
  function BillFilters$LASTUPDATEDDATESTART_getInstance() {
    BillFilters_initFields();
    return BillFilters$LASTUPDATEDDATESTART_instance;
  }
  var BillFilters$LASTUPDATEDDATEEND_instance;
  function BillFilters$LASTUPDATEDDATEEND_getInstance() {
    BillFilters_initFields();
    return BillFilters$LASTUPDATEDDATEEND_instance;
  }
  var BillFilters$LASTMAJORSTATUS_instance;
  function BillFilters$LASTMAJORSTATUS_getInstance() {
    BillFilters_initFields();
    return BillFilters$LASTMAJORSTATUS_instance;
  }
  BillFilters.prototype.htmlSelector = function () {
    return this.identifierCached_oe38wa$_0;
  };
  BillFilters.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'BillFilters',
    interfaces: [Enum]
  };
  function BillFilters$values() {
    return [BillFilters$IDENTITY_getInstance(), BillFilters$PARTY_getInstance(), BillFilters$FIXEDSTATUS_getInstance(), BillFilters$DATEINTROSTART_getInstance(), BillFilters$DATEINTROEND_getInstance(), BillFilters$LASTUPDATEDDATESTART_getInstance(), BillFilters$LASTUPDATEDDATEEND_getInstance(), BillFilters$LASTMAJORSTATUS_getInstance()];
  }
  BillFilters.values = BillFilters$values;
  function BillFilters$valueOf(name) {
    switch (name) {
      case 'IDENTITY':
        return BillFilters$IDENTITY_getInstance();
      case 'PARTY':
        return BillFilters$PARTY_getInstance();
      case 'FIXEDSTATUS':
        return BillFilters$FIXEDSTATUS_getInstance();
      case 'DATEINTROSTART':
        return BillFilters$DATEINTROSTART_getInstance();
      case 'DATEINTROEND':
        return BillFilters$DATEINTROEND_getInstance();
      case 'LASTUPDATEDDATESTART':
        return BillFilters$LASTUPDATEDDATESTART_getInstance();
      case 'LASTUPDATEDDATEEND':
        return BillFilters$LASTUPDATEDDATEEND_getInstance();
      case 'LASTMAJORSTATUS':
        return BillFilters$LASTMAJORSTATUS_getInstance();
      default:Kotlin.throwISE('No enum constant bz.stew.bracken.controller.bill.filter.BillFilters.' + name);
    }
  }
  BillFilters.valueOf_61zpoe$ = BillFilters$valueOf;
  function identity(a, b) {
    return false;
  }
  function partyPredicate(bill, selectVal) {
    var tmp$;
    var party = Kotlin.isType(tmp$ = selectVal, Party) ? tmp$ : Kotlin.throwCCE();
    if (Kotlin.equals(party, Party$NONE_getInstance())) {
      return true;
    }
    return Kotlin.equals(bill.sponsor.getParty(), party);
  }
  function statusPredicate(bill, selectVal) {
    var tmp$;
    var fs = Kotlin.isType(tmp$ = selectVal, FixedStatus) ? tmp$ : Kotlin.throwCCE();
    if (Kotlin.equals(fs, FixedStatus$NONE_getInstance())) {
      return true;
    }
    return Kotlin.equals(bill.status.fixedStatus, fs);
  }
  function FilterEntry() {
  }
  FilterEntry.$metadata$ = {
    kind: Kotlin.Kind.INTERFACE,
    simpleName: 'FilterEntry',
    interfaces: []
  };
  function flattenValueSets($receiver) {
    var tmp$;
    var out = Kotlin.kotlin.collections.ArrayList_init_ww73n8$();
    tmp$ = $receiver.values.iterator();
    while (tmp$.hasNext()) {
      var set_0 = tmp$.next();
      plus(out, set_0);
    }
    return out;
  }
  function flatten($receiver) {
    var tmp$;
    var out = Kotlin.kotlin.collections.ArrayList_init_ww73n8$();
    tmp$ = $receiver.iterator();
    while (tmp$.hasNext()) {
      var set_0 = tmp$.next();
      plus_0(out, set_0);
    }
    return out;
  }
  function BillData(uniqueId, title, congress, bill_type, bill_resolution_type, status, number, link, is_alive, is_current, intro_date, sponsor, majorActions, relatedBills) {
    if (uniqueId === void 0)
      uniqueId = -1;
    if (title === void 0)
      title = '';
    if (congress === void 0)
      congress = -1;
    if (number === void 0)
      number = -1;
    if (link === void 0)
      link = '';
    if (is_alive === void 0)
      is_alive = false;
    if (is_current === void 0)
      is_current = false;
    if (majorActions === void 0)
      majorActions = emptyList_0();
    this.uniqueId = uniqueId;
    this.title = title;
    this.congress = congress;
    this.bill_type = bill_type;
    this.bill_resolution_type = bill_resolution_type;
    this.status = status;
    this.number = number;
    this.link = link;
    this.is_alive = is_alive;
    this.is_current = is_current;
    this.intro_date = intro_date;
    this.sponsor = sponsor;
    this.majorActions = majorActions;
    this.relatedBills = relatedBills;
    var tmp$;
    var $receiver = this.majorActions;
    var maxBy$result;
    maxBy$break: {
      var iterator_3 = $receiver.iterator();
      if (!iterator_3.hasNext()) {
        maxBy$result = null;
        break maxBy$break;
      }
      var maxElem = iterator_3.next();
      var maxValue = maxElem.date().getTime();
      while (iterator_3.hasNext()) {
        var e = iterator_3.next();
        var v = e.date().getTime();
        if (Kotlin.compareTo(maxValue, v) < 0) {
          maxElem = e;
          maxValue = v;
        }
      }
      maxBy$result = maxElem;
    }
    this.lastMajorActionCached_0 = (tmp$ = maxBy$result) != null ? tmp$ : emptyMajorAction();
  }
  BillData.prototype.lastMajorAction = function () {
    return this.lastMajorActionCached_0;
  };
  BillData.prototype.lastMajorStatus = function () {
    return this.status.fixedStatus.lastMajorCompletedStatus;
  };
  BillData.prototype.lastUpdated = function () {
    var tmp$;
    return ((tmp$ = last(this.majorActions)) != null ? tmp$.date() : null).getTime();
  };
  BillData.prototype.toString = function () {
    return 'BillData' + '$' + this.uniqueId + '@' + this.intro_date.getTime();
  };
  BillData.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'BillData',
    interfaces: [ModelItem]
  };
  BillData.prototype.component1 = function () {
    return this.uniqueId;
  };
  BillData.prototype.component2 = function () {
    return this.title;
  };
  BillData.prototype.component3 = function () {
    return this.congress;
  };
  BillData.prototype.component4 = function () {
    return this.bill_type;
  };
  BillData.prototype.component5 = function () {
    return this.bill_resolution_type;
  };
  BillData.prototype.component6 = function () {
    return this.status;
  };
  BillData.prototype.component7 = function () {
    return this.number;
  };
  BillData.prototype.component8 = function () {
    return this.link;
  };
  BillData.prototype.component9 = function () {
    return this.is_alive;
  };
  BillData.prototype.component10 = function () {
    return this.is_current;
  };
  BillData.prototype.component11 = function () {
    return this.intro_date;
  };
  BillData.prototype.component12 = function () {
    return this.sponsor;
  };
  BillData.prototype.component13 = function () {
    return this.majorActions;
  };
  BillData.prototype.component14 = function () {
    return this.relatedBills;
  };
  BillData.prototype.copy_yzb1l0$ = function (uniqueId, title, congress, bill_type, bill_resolution_type, status, number, link, is_alive, is_current, intro_date, sponsor, majorActions, relatedBills) {
    return new BillData(uniqueId === void 0 ? this.uniqueId : uniqueId, title === void 0 ? this.title : title, congress === void 0 ? this.congress : congress, bill_type === void 0 ? this.bill_type : bill_type, bill_resolution_type === void 0 ? this.bill_resolution_type : bill_resolution_type, status === void 0 ? this.status : status, number === void 0 ? this.number : number, link === void 0 ? this.link : link, is_alive === void 0 ? this.is_alive : is_alive, is_current === void 0 ? this.is_current : is_current, intro_date === void 0 ? this.intro_date : intro_date, sponsor === void 0 ? this.sponsor : sponsor, majorActions === void 0 ? this.majorActions : majorActions, relatedBills === void 0 ? this.relatedBills : relatedBills);
  };
  BillData.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.uniqueId) | 0;
    result = result * 31 + Kotlin.hashCode(this.title) | 0;
    result = result * 31 + Kotlin.hashCode(this.congress) | 0;
    result = result * 31 + Kotlin.hashCode(this.bill_type) | 0;
    result = result * 31 + Kotlin.hashCode(this.bill_resolution_type) | 0;
    result = result * 31 + Kotlin.hashCode(this.status) | 0;
    result = result * 31 + Kotlin.hashCode(this.number) | 0;
    result = result * 31 + Kotlin.hashCode(this.link) | 0;
    result = result * 31 + Kotlin.hashCode(this.is_alive) | 0;
    result = result * 31 + Kotlin.hashCode(this.is_current) | 0;
    result = result * 31 + Kotlin.hashCode(this.intro_date) | 0;
    result = result * 31 + Kotlin.hashCode(this.sponsor) | 0;
    result = result * 31 + Kotlin.hashCode(this.majorActions) | 0;
    result = result * 31 + Kotlin.hashCode(this.relatedBills) | 0;
    return result;
  };
  BillData.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.uniqueId, other.uniqueId) && Kotlin.equals(this.title, other.title) && Kotlin.equals(this.congress, other.congress) && Kotlin.equals(this.bill_type, other.bill_type) && Kotlin.equals(this.bill_resolution_type, other.bill_resolution_type) && Kotlin.equals(this.status, other.status) && Kotlin.equals(this.number, other.number) && Kotlin.equals(this.link, other.link) && Kotlin.equals(this.is_alive, other.is_alive) && Kotlin.equals(this.is_current, other.is_current) && Kotlin.equals(this.intro_date, other.intro_date) && Kotlin.equals(this.sponsor, other.sponsor) && Kotlin.equals(this.majorActions, other.majorActions) && Kotlin.equals(this.relatedBills, other.relatedBills)))));
  };
  function BillProxy(uniqueId, context) {
    this.uniqueId = uniqueId;
    this.context = context;
  }
  BillProxy.prototype.getActualBill = function () {
    var tmp$;
    return (tmp$ = this.context.getBillById_za3lpa$(this.uniqueId)) != null ? tmp$ : Kotlin.throwNPE();
  };
  BillProxy.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'BillProxy',
    interfaces: []
  };
  function MajorAction() {
  }
  MajorAction.$metadata$ = {
    kind: Kotlin.Kind.INTERFACE,
    simpleName: 'MajorAction',
    interfaces: []
  };
  function emptyAction$ObjectLiteral() {
  }
  emptyAction$ObjectLiteral.prototype.id = function () {
    return 0;
  };
  emptyAction$ObjectLiteral.prototype.description = function () {
    return 'pizza';
  };
  emptyAction$ObjectLiteral.prototype.raw = function () {
    return '';
  };
  emptyAction$ObjectLiteral.prototype.date = function () {
    return Date(1990, 10, 23);
  };
  emptyAction$ObjectLiteral.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    interfaces: [MajorAction]
  };
  var emptyAction;
  function emptyMajorAction() {
    return emptyAction;
  }
  function RelatedBills() {
    this.relatedBills_0 = Kotlin.kotlin.collections.LinkedHashMap_init_q3lmfv$();
  }
  RelatedBills.prototype.add_9qqdc7$ = function (relation, bill) {
    var coll = this.relatedBills_0.get_11rb$(relation);
    if (coll == null) {
      coll = Kotlin.kotlin.collections.LinkedHashSet_init_287e2$();
      this.relatedBills_0.put_xwzc9p$(relation, coll);
    }
    (coll != null ? coll : Kotlin.throwNPE()).add_11rb$(bill);
  };
  RelatedBills.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'RelatedBills',
    interfaces: []
  };
  function Party(name, ordinal, niceString) {
    Enum.call(this);
    this.name$ = name;
    this.ordinal$ = ordinal;
    this.helper = new EPTypeHelper(niceString);
  }
  function Party_initFields() {
    Party_initFields = function () {
    };
    Party$NONE_instance = new Party('NONE', 0, 'None');
    Party$DEMOCRAT_instance = new Party('DEMOCRAT', 1, 'Democrat');
    Party$DEMON_instance = new Party('DEMON', 2, 'Demon');
    Party$REPUBLICAN_instance = new Party('REPUBLICAN', 3, 'Republican');
    Party$INDEPENDENT_instance = new Party('INDEPENDENT', 4, 'Independent');
  }
  var Party$NONE_instance;
  function Party$NONE_getInstance() {
    Party_initFields();
    return Party$NONE_instance;
  }
  var Party$DEMOCRAT_instance;
  function Party$DEMOCRAT_getInstance() {
    Party_initFields();
    return Party$DEMOCRAT_instance;
  }
  var Party$DEMON_instance;
  function Party$DEMON_getInstance() {
    Party_initFields();
    return Party$DEMON_instance;
  }
  var Party$REPUBLICAN_instance;
  function Party$REPUBLICAN_getInstance() {
    Party_initFields();
    return Party$REPUBLICAN_instance;
  }
  var Party$INDEPENDENT_instance;
  function Party$INDEPENDENT_getInstance() {
    Party_initFields();
    return Party$INDEPENDENT_instance;
  }
  Party.prototype.lowercaseName = function () {
    return this.helper.lowercaseName();
  };
  Party.prototype.capitalizedName = function () {
    return this.helper.capitalizedName();
  };
  Party.prototype.niceFormat = function () {
    return this.helper.niceFormat();
  };
  Party.prototype.shortLabel = function () {
    throw new UnsupportedOperationException('not implemented');
  };
  Party.prototype.toString = function () {
    return 'Party: ' + this.niceFormat();
  };
  Party.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'Party',
    interfaces: [Indexed, VisibleType, Enum]
  };
  function Party$values() {
    return [Party$NONE_getInstance(), Party$DEMOCRAT_getInstance(), Party$DEMON_getInstance(), Party$REPUBLICAN_getInstance(), Party$INDEPENDENT_getInstance()];
  }
  Party.values = Party$values;
  function Party$valueOf(name) {
    switch (name) {
      case 'NONE':
        return Party$NONE_getInstance();
      case 'DEMOCRAT':
        return Party$DEMOCRAT_getInstance();
      case 'DEMON':
        return Party$DEMON_getInstance();
      case 'REPUBLICAN':
        return Party$REPUBLICAN_getInstance();
      case 'INDEPENDENT':
        return Party$INDEPENDENT_getInstance();
      default:Kotlin.throwISE('No enum constant bz.stew.bracken.model.types.party.Party.' + name);
    }
  }
  Party.valueOf_61zpoe$ = Party$valueOf;
  function Legislator(id, name, party, role, state, twitterId) {
    this.id_0 = id;
    this.name_0 = name;
    this.party_0 = party;
    this.role_0 = role;
    this.state_0 = state;
    this.twitterId_0 = twitterId;
  }
  Legislator.prototype.getId = function () {
    return this.id_0;
  };
  Legislator.prototype.getName = function () {
    return this.name_0;
  };
  Legislator.prototype.getParty = function () {
    return this.party_0;
  };
  Legislator.prototype.getRole = function () {
    return this.role_0;
  };
  Legislator.prototype.getTwitterId = function () {
    return this.twitterId_0;
  };
  Legislator.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'Legislator',
    interfaces: [Person]
  };
  var EMPTY_LEG;
  function emptyLegislator() {
    return EMPTY_LEG;
  }
  function LegislatorRole(name, ordinal, niceString, shortLabel) {
    Enum.call(this);
    this.shortLabel_t80nnw$_0 = shortLabel;
    this.name$ = name;
    this.ordinal$ = ordinal;
    this.helper = new EPTypeHelper(niceString);
  }
  function LegislatorRole_initFields() {
    LegislatorRole_initFields = function () {
    };
    LegislatorRole$NONE_instance = new LegislatorRole('NONE', 0, 'None', 'None');
    LegislatorRole$SENATOR_instance = new LegislatorRole('SENATOR', 1, 'Senator', 'Sen.');
    LegislatorRole$REPRESENTATIVE_instance = new LegislatorRole('REPRESENTATIVE', 2, 'Representative', 'Rep.');
  }
  var LegislatorRole$NONE_instance;
  function LegislatorRole$NONE_getInstance() {
    LegislatorRole_initFields();
    return LegislatorRole$NONE_instance;
  }
  var LegislatorRole$SENATOR_instance;
  function LegislatorRole$SENATOR_getInstance() {
    LegislatorRole_initFields();
    return LegislatorRole$SENATOR_instance;
  }
  var LegislatorRole$REPRESENTATIVE_instance;
  function LegislatorRole$REPRESENTATIVE_getInstance() {
    LegislatorRole_initFields();
    return LegislatorRole$REPRESENTATIVE_instance;
  }
  LegislatorRole.prototype.lowercaseName = function () {
    return this.helper.lowercaseName();
  };
  LegislatorRole.prototype.capitalizedName = function () {
    return this.helper.capitalizedName();
  };
  LegislatorRole.prototype.niceFormat = function () {
    return this.helper.niceFormat();
  };
  LegislatorRole.prototype.shortLabel = function () {
    return this.shortLabel_t80nnw$_0;
  };
  LegislatorRole.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'LegislatorRole',
    interfaces: [VisibleType, Enum]
  };
  function LegislatorRole$values() {
    return [LegislatorRole$NONE_getInstance(), LegislatorRole$SENATOR_getInstance(), LegislatorRole$REPRESENTATIVE_getInstance()];
  }
  LegislatorRole.values = LegislatorRole$values;
  function LegislatorRole$valueOf(name) {
    switch (name) {
      case 'NONE':
        return LegislatorRole$NONE_getInstance();
      case 'SENATOR':
        return LegislatorRole$SENATOR_getInstance();
      case 'REPRESENTATIVE':
        return LegislatorRole$REPRESENTATIVE_getInstance();
      default:Kotlin.throwISE('No enum constant bz.stew.bracken.model.types.person.LegislatorRole.' + name);
    }
  }
  LegislatorRole.valueOf_61zpoe$ = LegislatorRole$valueOf;
  function Person() {
  }
  Person.$metadata$ = {
    kind: Kotlin.Kind.INTERFACE,
    simpleName: 'Person',
    interfaces: []
  };
  function BillDataGovTrack(model) {
    this.model_0 = model;
    this.title = '';
    this.uniqueParsedId = -1;
    this.congress = -1;
    this.bill_type = BillType$NONE_getInstance();
    this.bill_type_label = '';
    this.bill_resolution_type = BillResolutionType$NONE_getInstance();
    this.display_number = -1;
    this.current_status = emptyBillStatus();
    this.number = -1;
    this.link = '';
    this.is_alive = true;
    this.is_current = true;
    this.sponsor = emptyLegislator();
    this.introduced_date = new Date();
    this.majorActions = Kotlin.kotlin.collections.ArrayList_init_ww73n8$();
    this.relatedBills = new RelatedBills();
    this.displayNumber = 'None';
    this.dateRegex = Regex('(\\d{4})-(\\d{2})-(\\d{2})');
  }
  BillDataGovTrack.prototype.resolveType_ibkdai$ = function (values, matchToName) {
    var tmp$;
    for (tmp$ = 0; tmp$ !== values.length; ++tmp$) {
      var item = values[tmp$];
      var caps = item.capitalizedName();
      if (equals(caps, matchToName, true)) {
        return item;
      }
    }
    throw new IllegalStateException("Can't match type " + Kotlin.getKClassFromExpression(values[0]) + " with name = '" + matchToName + "'");
  };
  BillDataGovTrack.prototype.resolveMajorActions_za3rmp$ = function (actionArr) {
    var tmp$, tmp$_0, tmp$_1, tmp$_2;
    var length = actionArr.length;
    if (length <= 0) {
      return emptyList_0();
    }
    var out = Kotlin.kotlin.collections.ArrayList_init_ww73n8$();
    tmp$ = length - 1 | 0;
    for (var i = 0; i <= tmp$; i++) {
      var action = actionArr[i];
      try {
        var datetime = action[0];
        var id = action[1];
        var descr = action[2];
        var xml = action[3];
        var actionObj = new GovTrackMajorAction(typeof (tmp$_0 = datetime) === 'string' ? tmp$_0 : Kotlin.throwCCE(), id, typeof (tmp$_1 = descr) === 'string' ? tmp$_1 : Kotlin.throwCCE(), typeof (tmp$_2 = xml) === 'string' ? tmp$_2 : Kotlin.throwCCE());
        out.add_11rb$(actionObj);
      }
       catch (e) {
        if (Kotlin.isType(e, Exception)) {
          var message = 'error parsing this action: ' + e.toString();
          throw new Kotlin.kotlin.IllegalStateException(message.toString());
        }
         else
          throw e;
      }
    }
    return out;
  };
  BillDataGovTrack.prototype.parseDate_61zpoe$ = function (yyyymmdd) {
    var matches = this.dateRegex.findAll_905azu$(yyyymmdd);
    var matchGroups = matches.iterator().next().groupValues;
    var year = toInt(matchGroups.get_za3lpa$(1));
    var month = toInt(matchGroups.get_za3lpa$(2)) - 1 | 0;
    var day = toInt(matchGroups.get_za3lpa$(3));
    var d = new Date(year, month, day);
    return d;
  };
  BillDataGovTrack.prototype.resolveRelatedBills_za3rmp$ = function (relatedArray) {
    var tmp$;
    var length = relatedArray.length;
    if (length <= 0) {
      return new RelatedBills();
    }
    var rltBills = new RelatedBills();
    tmp$ = length - 1 | 0;
    for (var i = 0; i <= tmp$; i++) {
      try {
        var bill = relatedArray[i].bill;
        var relation = relatedArray[i].relation;
        rltBills.add_9qqdc7$(relation, new BillProxy(bill, this.model_0));
      }
       catch (ex) {
        if (Kotlin.isType(ex, ClassCastException)) {
          Log$LogCompanion_getInstance().warning_61zpoe$('Could not create bill, bad data parsing');
        }
         else if (Kotlin.isType(ex, NullPointerException)) {
          Log$LogCompanion_getInstance().warning_61zpoe$('Could not create bill: bill array out of index');
        }
         else
          throw ex;
      }
    }
    return rltBills;
  };
  BillDataGovTrack.prototype.build_za3rmp$ = function (govInput) {
    var tmp$, tmp$_0, tmp$_1;
    var gi = govInput;
    this.title = gi.title_without_number;
    this.uniqueParsedId = gi.id;
    var existingBill = this.model_0.getBillById_za3lpa$(this.uniqueParsedId);
    if (existingBill != null) {
      return existingBill;
    }
    this.congress = gi.congress;
    this.bill_type = Kotlin.isType(tmp$ = this.resolveType_ibkdai$(BillType$values(), JsonUtil$Parse_getInstance().niceString_61zpoe$(gi.bill_type)), BillType) ? tmp$ : Kotlin.throwCCE();
    this.bill_resolution_type = gi.bill_resolution_type;
    this.display_number = gi.display_number;
    this.current_status = new BillStatus(FixedStatus$valueOf(gi.current_status), new Date(), gi.current_status_description, gi.current_status_label);
    this.number = gi.number;
    this.link = gi.link;
    this.is_alive = gi.is_alive;
    this.is_current = gi.is_current;
    this.introduced_date = this.parseDate_61zpoe$(gi.introduced_date);
    var party = Kotlin.isType(tmp$_0 = this.resolveType_ibkdai$(Party$values(), JsonUtil$Parse_getInstance().niceString_61zpoe$(gi.sponsor_role.party)), Party) ? tmp$_0 : Kotlin.throwCCE();
    var sponsorRole = Kotlin.isType(tmp$_1 = this.resolveType_ibkdai$(LegislatorRole$values(), JsonUtil$Parse_getInstance().niceString_61zpoe$(gi.sponsor_role.role_type)), LegislatorRole) ? tmp$_1 : Kotlin.throwCCE();
    this.sponsor = new Legislator(gi.sponsor.id, gi.sponsor.name, party, sponsorRole, gi.sponsor_role.state, gi.sponsor.twitterid);
    this.majorActions = this.resolveMajorActions_za3rmp$(gi.major_actions);
    this.relatedBills = this.resolveRelatedBills_za3rmp$(gi.related_bills);
    return new BillData(this.uniqueParsedId, this.title, this.congress, this.bill_type, this.bill_resolution_type, this.current_status, this.number, this.link, this.is_alive, this.is_current, this.introduced_date, this.sponsor, this.majorActions, this.relatedBills);
  };
  BillDataGovTrack.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'BillDataGovTrack',
    interfaces: []
  };
  var dateRegex;
  function GovTrackMajorAction(date, id, description, xml) {
    if (id === void 0)
      id = -1;
    if (description === void 0)
      description = 'none';
    if (xml === void 0)
      xml = 'none';
    this.id_0 = id;
    this.description_0 = description;
    this.xml_0 = xml;
    this.date_0 = this.resolveDate_0(date);
  }
  GovTrackMajorAction.prototype.resolveDate_0 = function (dateString) {
    var matches = dateRegex.findAll_905azu$(dateString);
    var matchGroups = matches.iterator().next().groupValues;
    var year = toInt(matchGroups.get_za3lpa$(1));
    var month = toInt(matchGroups.get_za3lpa$(2)) - 1 | 0;
    var day = toInt(matchGroups.get_za3lpa$(3));
    var d = new Date(year, month, day);
    return d;
  };
  GovTrackMajorAction.prototype.id = function () {
    return this.id_0;
  };
  GovTrackMajorAction.prototype.description = function () {
    return this.description_0;
  };
  GovTrackMajorAction.prototype.raw = function () {
    return this.xml_0;
  };
  GovTrackMajorAction.prototype.date = function () {
    return this.date_0;
  };
  GovTrackMajorAction.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'GovTrackMajorAction',
    interfaces: [MajorAction]
  };
  function BillStatus(fixedStatus, date, description, label) {
    this.fixedStatus = fixedStatus;
    this.date = date;
    this.description = description;
    this.label = label;
  }
  BillStatus.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'BillStatus',
    interfaces: []
  };
  BillStatus.prototype.component1 = function () {
    return this.fixedStatus;
  };
  BillStatus.prototype.component2 = function () {
    return this.date;
  };
  BillStatus.prototype.component3 = function () {
    return this.description;
  };
  BillStatus.prototype.component4 = function () {
    return this.label;
  };
  BillStatus.prototype.copy_2p7scw$ = function (fixedStatus, date, description, label) {
    return new BillStatus(fixedStatus === void 0 ? this.fixedStatus : fixedStatus, date === void 0 ? this.date : date, description === void 0 ? this.description : description, label === void 0 ? this.label : label);
  };
  BillStatus.prototype.toString = function () {
    return 'BillStatus(fixedStatus=' + Kotlin.toString(this.fixedStatus) + (', date=' + Kotlin.toString(this.date)) + (', description=' + Kotlin.toString(this.description)) + (', label=' + Kotlin.toString(this.label)) + ')';
  };
  BillStatus.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.fixedStatus) | 0;
    result = result * 31 + Kotlin.hashCode(this.date) | 0;
    result = result * 31 + Kotlin.hashCode(this.description) | 0;
    result = result * 31 + Kotlin.hashCode(this.label) | 0;
    return result;
  };
  BillStatus.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.fixedStatus, other.fixedStatus) && Kotlin.equals(this.date, other.date) && Kotlin.equals(this.description, other.description) && Kotlin.equals(this.label, other.label)))));
  };
  var EMPTY_BILL_STATUS;
  function emptyBillStatus() {
    return EMPTY_BILL_STATUS;
  }
  function FixedStatus(name, ordinal, lastMajorCompletedStatus) {
    FixedStatus$Companion_getInstance();
    if (lastMajorCompletedStatus === void 0)
      lastMajorCompletedStatus = MajorStatus$NONE_getInstance();
    Enum.call(this);
    this.lastMajorCompletedStatus = lastMajorCompletedStatus;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function FixedStatus_initFields() {
    FixedStatus_initFields = function () {
    };
    FixedStatus$NONE_instance = new FixedStatus('NONE', 0);
    FixedStatus$prov_kill_veto_instance = new FixedStatus('prov_kill_veto', 1, MajorStatus$FAILED_getInstance());
    FixedStatus$fail_second_senate_instance = new FixedStatus('fail_second_senate', 2, MajorStatus$FAILED_getInstance());
    FixedStatus$passed_bill_instance = new FixedStatus('passed_bill', 3, MajorStatus$PASSED_SENATE_getInstance());
    FixedStatus$passed_constamend_instance = new FixedStatus('passed_constamend', 4, MajorStatus$PASSED_SENATE_getInstance());
    FixedStatus$pass_back_senate_instance = new FixedStatus('pass_back_senate', 5, MajorStatus$PASSED_SENATE_getInstance());
    FixedStatus$vetoed_override_fail_second_house_instance = new FixedStatus('vetoed_override_fail_second_house', 6, MajorStatus$FAILED_getInstance());
    FixedStatus$fail_originating_house_instance = new FixedStatus('fail_originating_house', 7, MajorStatus$FAILED_getInstance());
    FixedStatus$fail_second_house_instance = new FixedStatus('fail_second_house', 8, MajorStatus$FAILED_getInstance());
    FixedStatus$override_pass_over_house_instance = new FixedStatus('override_pass_over_house', 9, MajorStatus$PASSED_HOUSE_getInstance());
    FixedStatus$override_pass_over_senate_instance = new FixedStatus('override_pass_over_senate', 10, MajorStatus$PASSED_SENATE_getInstance());
    FixedStatus$pass_back_house_instance = new FixedStatus('pass_back_house', 11, MajorStatus$PASSED_HOUSE_getInstance());
    FixedStatus$prov_kill_cloturefailed_instance = new FixedStatus('prov_kill_cloturefailed', 12, MajorStatus$FAILED_getInstance());
    FixedStatus$enacted_veto_override_instance = new FixedStatus('enacted_veto_override', 13, MajorStatus$LAW_getInstance());
    FixedStatus$passed_concurrentres_instance = new FixedStatus('passed_concurrentres', 14, MajorStatus$PASSED_SENATE_getInstance());
    FixedStatus$prov_kill_suspensionfailed_instance = new FixedStatus('prov_kill_suspensionfailed', 15, MajorStatus$FAILED_getInstance());
    FixedStatus$passed_simpleres_instance = new FixedStatus('passed_simpleres', 16, MajorStatus$PASSED_SENATE_getInstance());
    FixedStatus$vetoed_pocket_instance = new FixedStatus('vetoed_pocket', 17, MajorStatus$FAILED_getInstance());
    FixedStatus$vetoed_override_fail_originating_house_instance = new FixedStatus('vetoed_override_fail_originating_house', 18);
    FixedStatus$conference_passed_senate_instance = new FixedStatus('conference_passed_senate', 19, MajorStatus$PASSED_SENATE_getInstance());
    FixedStatus$fail_originating_senate_instance = new FixedStatus('fail_originating_senate', 20, MajorStatus$FAILED_getInstance());
    FixedStatus$pass_over_senate_instance = new FixedStatus('pass_over_senate', 21, MajorStatus$PASSED_SENATE_getInstance());
    FixedStatus$prov_kill_pingpongfail_instance = new FixedStatus('prov_kill_pingpongfail', 22, MajorStatus$FAILED_getInstance());
    FixedStatus$enacted_signed_instance = new FixedStatus('enacted_signed', 23, MajorStatus$LAW_getInstance());
    FixedStatus$pass_over_house_instance = new FixedStatus('pass_over_house', 24, MajorStatus$PASSED_HOUSE_getInstance());
    FixedStatus$conference_passed_house_instance = new FixedStatus('conference_passed_house', 25, MajorStatus$PASSED_HOUSE_getInstance());
    FixedStatus$reported_instance = new FixedStatus('reported', 26, MajorStatus$INTRODUCED_getInstance());
    FixedStatus$vetoed_override_fail_second_senate_instance = new FixedStatus('vetoed_override_fail_second_senate', 27, MajorStatus$FAILED_getInstance());
    FixedStatus$vetoed_override_fail_originating_senate_instance = new FixedStatus('vetoed_override_fail_originating_senate', 28, MajorStatus$FAILED_getInstance());
    FixedStatus$enacted_tendayrule_instance = new FixedStatus('enacted_tendayrule', 29, MajorStatus$LAW_getInstance());
    FixedStatus$introduced_instance = new FixedStatus('introduced', 30, MajorStatus$INTRODUCED_getInstance());
    FixedStatus$enacted_unknown_instance = new FixedStatus('enacted_unknown', 31, MajorStatus$LAW_getInstance());
    FixedStatus$referred_instance = new FixedStatus('referred', 32, MajorStatus$INTRODUCED_getInstance());
  }
  var FixedStatus$NONE_instance;
  function FixedStatus$NONE_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$NONE_instance;
  }
  var FixedStatus$prov_kill_veto_instance;
  function FixedStatus$prov_kill_veto_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$prov_kill_veto_instance;
  }
  var FixedStatus$fail_second_senate_instance;
  function FixedStatus$fail_second_senate_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$fail_second_senate_instance;
  }
  var FixedStatus$passed_bill_instance;
  function FixedStatus$passed_bill_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$passed_bill_instance;
  }
  var FixedStatus$passed_constamend_instance;
  function FixedStatus$passed_constamend_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$passed_constamend_instance;
  }
  var FixedStatus$pass_back_senate_instance;
  function FixedStatus$pass_back_senate_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$pass_back_senate_instance;
  }
  var FixedStatus$vetoed_override_fail_second_house_instance;
  function FixedStatus$vetoed_override_fail_second_house_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$vetoed_override_fail_second_house_instance;
  }
  var FixedStatus$fail_originating_house_instance;
  function FixedStatus$fail_originating_house_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$fail_originating_house_instance;
  }
  var FixedStatus$fail_second_house_instance;
  function FixedStatus$fail_second_house_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$fail_second_house_instance;
  }
  var FixedStatus$override_pass_over_house_instance;
  function FixedStatus$override_pass_over_house_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$override_pass_over_house_instance;
  }
  var FixedStatus$override_pass_over_senate_instance;
  function FixedStatus$override_pass_over_senate_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$override_pass_over_senate_instance;
  }
  var FixedStatus$pass_back_house_instance;
  function FixedStatus$pass_back_house_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$pass_back_house_instance;
  }
  var FixedStatus$prov_kill_cloturefailed_instance;
  function FixedStatus$prov_kill_cloturefailed_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$prov_kill_cloturefailed_instance;
  }
  var FixedStatus$enacted_veto_override_instance;
  function FixedStatus$enacted_veto_override_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$enacted_veto_override_instance;
  }
  var FixedStatus$passed_concurrentres_instance;
  function FixedStatus$passed_concurrentres_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$passed_concurrentres_instance;
  }
  var FixedStatus$prov_kill_suspensionfailed_instance;
  function FixedStatus$prov_kill_suspensionfailed_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$prov_kill_suspensionfailed_instance;
  }
  var FixedStatus$passed_simpleres_instance;
  function FixedStatus$passed_simpleres_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$passed_simpleres_instance;
  }
  var FixedStatus$vetoed_pocket_instance;
  function FixedStatus$vetoed_pocket_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$vetoed_pocket_instance;
  }
  var FixedStatus$vetoed_override_fail_originating_house_instance;
  function FixedStatus$vetoed_override_fail_originating_house_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$vetoed_override_fail_originating_house_instance;
  }
  var FixedStatus$conference_passed_senate_instance;
  function FixedStatus$conference_passed_senate_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$conference_passed_senate_instance;
  }
  var FixedStatus$fail_originating_senate_instance;
  function FixedStatus$fail_originating_senate_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$fail_originating_senate_instance;
  }
  var FixedStatus$pass_over_senate_instance;
  function FixedStatus$pass_over_senate_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$pass_over_senate_instance;
  }
  var FixedStatus$prov_kill_pingpongfail_instance;
  function FixedStatus$prov_kill_pingpongfail_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$prov_kill_pingpongfail_instance;
  }
  var FixedStatus$enacted_signed_instance;
  function FixedStatus$enacted_signed_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$enacted_signed_instance;
  }
  var FixedStatus$pass_over_house_instance;
  function FixedStatus$pass_over_house_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$pass_over_house_instance;
  }
  var FixedStatus$conference_passed_house_instance;
  function FixedStatus$conference_passed_house_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$conference_passed_house_instance;
  }
  var FixedStatus$reported_instance;
  function FixedStatus$reported_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$reported_instance;
  }
  var FixedStatus$vetoed_override_fail_second_senate_instance;
  function FixedStatus$vetoed_override_fail_second_senate_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$vetoed_override_fail_second_senate_instance;
  }
  var FixedStatus$vetoed_override_fail_originating_senate_instance;
  function FixedStatus$vetoed_override_fail_originating_senate_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$vetoed_override_fail_originating_senate_instance;
  }
  var FixedStatus$enacted_tendayrule_instance;
  function FixedStatus$enacted_tendayrule_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$enacted_tendayrule_instance;
  }
  var FixedStatus$introduced_instance;
  function FixedStatus$introduced_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$introduced_instance;
  }
  var FixedStatus$enacted_unknown_instance;
  function FixedStatus$enacted_unknown_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$enacted_unknown_instance;
  }
  var FixedStatus$referred_instance;
  function FixedStatus$referred_getInstance() {
    FixedStatus_initFields();
    return FixedStatus$referred_instance;
  }
  function FixedStatus$Companion() {
    FixedStatus$Companion_instance = this;
  }
  FixedStatus$Companion.prototype.valueAt_za3lpa$ = function (i) {
    var tmp$, tmp$_0;
    tmp$ = FixedStatus$values();
    for (tmp$_0 = 0; tmp$_0 !== tmp$.length; ++tmp$_0) {
      var fs = tmp$[tmp$_0];
      if (fs.ordinal === i) {
        return fs;
      }
    }
    throw new IllegalArgumentException("Can't convert int of value " + i + ' to FixedStatus enum.');
  };
  FixedStatus$Companion.$metadata$ = {
    kind: Kotlin.Kind.OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var FixedStatus$Companion_instance = null;
  function FixedStatus$Companion_getInstance() {
    if (FixedStatus$Companion_instance === null) {
      new FixedStatus$Companion();
    }
    return FixedStatus$Companion_instance;
  }
  FixedStatus.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'FixedStatus',
    interfaces: [Indexed, Enum]
  };
  function FixedStatus$values() {
    return [FixedStatus$NONE_getInstance(), FixedStatus$prov_kill_veto_getInstance(), FixedStatus$fail_second_senate_getInstance(), FixedStatus$passed_bill_getInstance(), FixedStatus$passed_constamend_getInstance(), FixedStatus$pass_back_senate_getInstance(), FixedStatus$vetoed_override_fail_second_house_getInstance(), FixedStatus$fail_originating_house_getInstance(), FixedStatus$fail_second_house_getInstance(), FixedStatus$override_pass_over_house_getInstance(), FixedStatus$override_pass_over_senate_getInstance(), FixedStatus$pass_back_house_getInstance(), FixedStatus$prov_kill_cloturefailed_getInstance(), FixedStatus$enacted_veto_override_getInstance(), FixedStatus$passed_concurrentres_getInstance(), FixedStatus$prov_kill_suspensionfailed_getInstance(), FixedStatus$passed_simpleres_getInstance(), FixedStatus$vetoed_pocket_getInstance(), FixedStatus$vetoed_override_fail_originating_house_getInstance(), FixedStatus$conference_passed_senate_getInstance(), FixedStatus$fail_originating_senate_getInstance(), FixedStatus$pass_over_senate_getInstance(), FixedStatus$prov_kill_pingpongfail_getInstance(), FixedStatus$enacted_signed_getInstance(), FixedStatus$pass_over_house_getInstance(), FixedStatus$conference_passed_house_getInstance(), FixedStatus$reported_getInstance(), FixedStatus$vetoed_override_fail_second_senate_getInstance(), FixedStatus$vetoed_override_fail_originating_senate_getInstance(), FixedStatus$enacted_tendayrule_getInstance(), FixedStatus$introduced_getInstance(), FixedStatus$enacted_unknown_getInstance(), FixedStatus$referred_getInstance()];
  }
  FixedStatus.values = FixedStatus$values;
  function FixedStatus$valueOf(name) {
    switch (name) {
      case 'NONE':
        return FixedStatus$NONE_getInstance();
      case 'prov_kill_veto':
        return FixedStatus$prov_kill_veto_getInstance();
      case 'fail_second_senate':
        return FixedStatus$fail_second_senate_getInstance();
      case 'passed_bill':
        return FixedStatus$passed_bill_getInstance();
      case 'passed_constamend':
        return FixedStatus$passed_constamend_getInstance();
      case 'pass_back_senate':
        return FixedStatus$pass_back_senate_getInstance();
      case 'vetoed_override_fail_second_house':
        return FixedStatus$vetoed_override_fail_second_house_getInstance();
      case 'fail_originating_house':
        return FixedStatus$fail_originating_house_getInstance();
      case 'fail_second_house':
        return FixedStatus$fail_second_house_getInstance();
      case 'override_pass_over_house':
        return FixedStatus$override_pass_over_house_getInstance();
      case 'override_pass_over_senate':
        return FixedStatus$override_pass_over_senate_getInstance();
      case 'pass_back_house':
        return FixedStatus$pass_back_house_getInstance();
      case 'prov_kill_cloturefailed':
        return FixedStatus$prov_kill_cloturefailed_getInstance();
      case 'enacted_veto_override':
        return FixedStatus$enacted_veto_override_getInstance();
      case 'passed_concurrentres':
        return FixedStatus$passed_concurrentres_getInstance();
      case 'prov_kill_suspensionfailed':
        return FixedStatus$prov_kill_suspensionfailed_getInstance();
      case 'passed_simpleres':
        return FixedStatus$passed_simpleres_getInstance();
      case 'vetoed_pocket':
        return FixedStatus$vetoed_pocket_getInstance();
      case 'vetoed_override_fail_originating_house':
        return FixedStatus$vetoed_override_fail_originating_house_getInstance();
      case 'conference_passed_senate':
        return FixedStatus$conference_passed_senate_getInstance();
      case 'fail_originating_senate':
        return FixedStatus$fail_originating_senate_getInstance();
      case 'pass_over_senate':
        return FixedStatus$pass_over_senate_getInstance();
      case 'prov_kill_pingpongfail':
        return FixedStatus$prov_kill_pingpongfail_getInstance();
      case 'enacted_signed':
        return FixedStatus$enacted_signed_getInstance();
      case 'pass_over_house':
        return FixedStatus$pass_over_house_getInstance();
      case 'conference_passed_house':
        return FixedStatus$conference_passed_house_getInstance();
      case 'reported':
        return FixedStatus$reported_getInstance();
      case 'vetoed_override_fail_second_senate':
        return FixedStatus$vetoed_override_fail_second_senate_getInstance();
      case 'vetoed_override_fail_originating_senate':
        return FixedStatus$vetoed_override_fail_originating_senate_getInstance();
      case 'enacted_tendayrule':
        return FixedStatus$enacted_tendayrule_getInstance();
      case 'introduced':
        return FixedStatus$introduced_getInstance();
      case 'enacted_unknown':
        return FixedStatus$enacted_unknown_getInstance();
      case 'referred':
        return FixedStatus$referred_getInstance();
      default:Kotlin.throwISE('No enum constant bz.stew.bracken.model.types.bill.status.FixedStatus.' + name);
    }
  }
  FixedStatus.valueOf_61zpoe$ = FixedStatus$valueOf;
  function MajorStatus(name, ordinal, viewString) {
    MajorStatus$Companion_getInstance();
    if (viewString === void 0)
      viewString = ViewConstants$Empty_getInstance();
    Enum.call(this);
    this.viewString = viewString;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function MajorStatus_initFields() {
    MajorStatus_initFields = function () {
    };
    MajorStatus$NONE_instance = new MajorStatus('NONE', 0, ViewConstants$Empty_getInstance());
    MajorStatus$INTRODUCED_instance = new MajorStatus('INTRODUCED', 1, ViewConstants$Introduced_getInstance());
    MajorStatus$FAILED_instance = new MajorStatus('FAILED', 2, ViewConstants$Failed_getInstance());
    MajorStatus$PASSED_HOUSE_instance = new MajorStatus('PASSED_HOUSE', 3, ViewConstants$PassedHouse_getInstance());
    MajorStatus$PASSED_SENATE_instance = new MajorStatus('PASSED_SENATE', 4, ViewConstants$PassedSenate_getInstance());
    MajorStatus$SIGNED_PRESIDENT_instance = new MajorStatus('SIGNED_PRESIDENT', 5, ViewConstants$SignedByPresident_getInstance());
    MajorStatus$LAW_instance = new MajorStatus('LAW', 6, ViewConstants$EnactedLaw_getInstance());
  }
  var MajorStatus$NONE_instance;
  function MajorStatus$NONE_getInstance() {
    MajorStatus_initFields();
    return MajorStatus$NONE_instance;
  }
  var MajorStatus$INTRODUCED_instance;
  function MajorStatus$INTRODUCED_getInstance() {
    MajorStatus_initFields();
    return MajorStatus$INTRODUCED_instance;
  }
  var MajorStatus$FAILED_instance;
  function MajorStatus$FAILED_getInstance() {
    MajorStatus_initFields();
    return MajorStatus$FAILED_instance;
  }
  var MajorStatus$PASSED_HOUSE_instance;
  function MajorStatus$PASSED_HOUSE_getInstance() {
    MajorStatus_initFields();
    return MajorStatus$PASSED_HOUSE_instance;
  }
  var MajorStatus$PASSED_SENATE_instance;
  function MajorStatus$PASSED_SENATE_getInstance() {
    MajorStatus_initFields();
    return MajorStatus$PASSED_SENATE_instance;
  }
  var MajorStatus$SIGNED_PRESIDENT_instance;
  function MajorStatus$SIGNED_PRESIDENT_getInstance() {
    MajorStatus_initFields();
    return MajorStatus$SIGNED_PRESIDENT_instance;
  }
  var MajorStatus$LAW_instance;
  function MajorStatus$LAW_getInstance() {
    MajorStatus_initFields();
    return MajorStatus$LAW_instance;
  }
  MajorStatus.prototype.lowercaseName = function () {
    return this.viewString.lowercaseName();
  };
  MajorStatus.prototype.capitalizedName = function () {
    return this.viewString.capitalizedName();
  };
  MajorStatus.prototype.niceFormat = function () {
    return this.viewString.niceFormat();
  };
  MajorStatus.prototype.shortLabel = function () {
    return this.viewString.shortLabel();
  };
  function MajorStatus$Companion() {
    MajorStatus$Companion_instance = this;
  }
  MajorStatus$Companion.prototype.valueAt_za3lpa$ = function (i) {
    var tmp$, tmp$_0;
    tmp$ = MajorStatus$values();
    for (tmp$_0 = 0; tmp$_0 !== tmp$.length; ++tmp$_0) {
      var fs = tmp$[tmp$_0];
      if (fs.ordinal === i) {
        return fs;
      }
    }
    throw new IllegalArgumentException("Can't convert int of value " + i + ' to MajorStatus.');
  };
  MajorStatus$Companion.$metadata$ = {
    kind: Kotlin.Kind.OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var MajorStatus$Companion_instance = null;
  function MajorStatus$Companion_getInstance() {
    if (MajorStatus$Companion_instance === null) {
      new MajorStatus$Companion();
    }
    return MajorStatus$Companion_instance;
  }
  MajorStatus.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'MajorStatus',
    interfaces: [VisibleType, Enum]
  };
  function MajorStatus$values() {
    return [MajorStatus$NONE_getInstance(), MajorStatus$INTRODUCED_getInstance(), MajorStatus$FAILED_getInstance(), MajorStatus$PASSED_HOUSE_getInstance(), MajorStatus$PASSED_SENATE_getInstance(), MajorStatus$SIGNED_PRESIDENT_getInstance(), MajorStatus$LAW_getInstance()];
  }
  MajorStatus.values = MajorStatus$values;
  function MajorStatus$valueOf(name) {
    switch (name) {
      case 'NONE':
        return MajorStatus$NONE_getInstance();
      case 'INTRODUCED':
        return MajorStatus$INTRODUCED_getInstance();
      case 'FAILED':
        return MajorStatus$FAILED_getInstance();
      case 'PASSED_HOUSE':
        return MajorStatus$PASSED_HOUSE_getInstance();
      case 'PASSED_SENATE':
        return MajorStatus$PASSED_SENATE_getInstance();
      case 'SIGNED_PRESIDENT':
        return MajorStatus$SIGNED_PRESIDENT_getInstance();
      case 'LAW':
        return MajorStatus$LAW_getInstance();
      default:Kotlin.throwISE('No enum constant bz.stew.bracken.model.types.bill.status.MajorStatus.' + name);
    }
  }
  MajorStatus.valueOf_61zpoe$ = MajorStatus$valueOf;
  function BillResolutionType(name, ordinal, niceString, shortLabel) {
    Enum.call(this);
    this.shortLabel_lwizj8$_0 = shortLabel;
    this.name$ = name;
    this.ordinal$ = ordinal;
    this.helper = new EPTypeHelper(niceString);
  }
  function BillResolutionType_initFields() {
    BillResolutionType_initFields = function () {
    };
    BillResolutionType$NONE_instance = new BillResolutionType('NONE', 0, 'None', 'None');
    BillResolutionType$BILL_instance = new BillResolutionType('BILL', 1, 'Bill', 'Bill');
    BillResolutionType$RESOLUTION_instance = new BillResolutionType('RESOLUTION', 2, 'Resolution', 'Res.');
  }
  var BillResolutionType$NONE_instance;
  function BillResolutionType$NONE_getInstance() {
    BillResolutionType_initFields();
    return BillResolutionType$NONE_instance;
  }
  var BillResolutionType$BILL_instance;
  function BillResolutionType$BILL_getInstance() {
    BillResolutionType_initFields();
    return BillResolutionType$BILL_instance;
  }
  var BillResolutionType$RESOLUTION_instance;
  function BillResolutionType$RESOLUTION_getInstance() {
    BillResolutionType_initFields();
    return BillResolutionType$RESOLUTION_instance;
  }
  BillResolutionType.prototype.lowercaseName = function () {
    return this.helper.lowercaseName();
  };
  BillResolutionType.prototype.capitalizedName = function () {
    return this.helper.capitalizedName();
  };
  BillResolutionType.prototype.niceFormat = function () {
    return this.helper.niceFormat();
  };
  BillResolutionType.prototype.shortLabel = function () {
    return this.shortLabel_lwizj8$_0;
  };
  BillResolutionType.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'BillResolutionType',
    interfaces: [VisibleType, Enum]
  };
  function BillResolutionType$values() {
    return [BillResolutionType$NONE_getInstance(), BillResolutionType$BILL_getInstance(), BillResolutionType$RESOLUTION_getInstance()];
  }
  BillResolutionType.values = BillResolutionType$values;
  function BillResolutionType$valueOf(name) {
    switch (name) {
      case 'NONE':
        return BillResolutionType$NONE_getInstance();
      case 'BILL':
        return BillResolutionType$BILL_getInstance();
      case 'RESOLUTION':
        return BillResolutionType$RESOLUTION_getInstance();
      default:Kotlin.throwISE('No enum constant bz.stew.bracken.model.types.bill.types.BillResolutionType.' + name);
    }
  }
  BillResolutionType.valueOf_61zpoe$ = BillResolutionType$valueOf;
  function BillType(name, ordinal, niceString, shortLabel) {
    Enum.call(this);
    this.shortLabel_bcbuvs$_0 = shortLabel;
    this.name$ = name;
    this.ordinal$ = ordinal;
    this.helper_bcbuvs$_0 = new EPTypeHelper(niceString);
  }
  function BillType_initFields() {
    BillType_initFields = function () {
    };
    BillType$NONE_instance = new BillType('NONE', 0, 'None', 'None.');
    BillType$SENATE_BILL_instance = new BillType('SENATE_BILL', 1, 'Senate Bill', 'S.');
    BillType$HOUSE_BILL_instance = new BillType('HOUSE_BILL', 2, 'House Bill', 'H.R.');
    BillType$SENATE_RESOLUTION_instance = new BillType('SENATE_RESOLUTION', 3, 'Senate Resolution', 'S.Res.');
    BillType$HOUSE_RESOLUTION_instance = new BillType('HOUSE_RESOLUTION', 4, 'House Resolution', 'H.Res.');
    BillType$SENATE_CONCURRENT_RESOLUTION_instance = new BillType('SENATE_CONCURRENT_RESOLUTION', 5, 'Senate Concurrent Resolution', 'S.Con.Res');
    BillType$HOUSE_CONCURRENT_RESOLUTION_instance = new BillType('HOUSE_CONCURRENT_RESOLUTION', 6, 'House Concurrent Resolution', 'H.Con.Res.');
    BillType$SENATE_JOINT_RESOLUTION_instance = new BillType('SENATE_JOINT_RESOLUTION', 7, 'Senate Joint Resolution', 'S.J.Res.');
    BillType$HOUSE_JOINT_RESOLUTION_instance = new BillType('HOUSE_JOINT_RESOLUTION', 8, 'House Joint Resolution', 'H.J.Res.');
  }
  var BillType$NONE_instance;
  function BillType$NONE_getInstance() {
    BillType_initFields();
    return BillType$NONE_instance;
  }
  var BillType$SENATE_BILL_instance;
  function BillType$SENATE_BILL_getInstance() {
    BillType_initFields();
    return BillType$SENATE_BILL_instance;
  }
  var BillType$HOUSE_BILL_instance;
  function BillType$HOUSE_BILL_getInstance() {
    BillType_initFields();
    return BillType$HOUSE_BILL_instance;
  }
  var BillType$SENATE_RESOLUTION_instance;
  function BillType$SENATE_RESOLUTION_getInstance() {
    BillType_initFields();
    return BillType$SENATE_RESOLUTION_instance;
  }
  var BillType$HOUSE_RESOLUTION_instance;
  function BillType$HOUSE_RESOLUTION_getInstance() {
    BillType_initFields();
    return BillType$HOUSE_RESOLUTION_instance;
  }
  var BillType$SENATE_CONCURRENT_RESOLUTION_instance;
  function BillType$SENATE_CONCURRENT_RESOLUTION_getInstance() {
    BillType_initFields();
    return BillType$SENATE_CONCURRENT_RESOLUTION_instance;
  }
  var BillType$HOUSE_CONCURRENT_RESOLUTION_instance;
  function BillType$HOUSE_CONCURRENT_RESOLUTION_getInstance() {
    BillType_initFields();
    return BillType$HOUSE_CONCURRENT_RESOLUTION_instance;
  }
  var BillType$SENATE_JOINT_RESOLUTION_instance;
  function BillType$SENATE_JOINT_RESOLUTION_getInstance() {
    BillType_initFields();
    return BillType$SENATE_JOINT_RESOLUTION_instance;
  }
  var BillType$HOUSE_JOINT_RESOLUTION_instance;
  function BillType$HOUSE_JOINT_RESOLUTION_getInstance() {
    BillType_initFields();
    return BillType$HOUSE_JOINT_RESOLUTION_instance;
  }
  BillType.prototype.lowercaseName = function () {
    return this.helper_bcbuvs$_0.lowercaseName();
  };
  BillType.prototype.capitalizedName = function () {
    return this.helper_bcbuvs$_0.capitalizedName();
  };
  BillType.prototype.niceFormat = function () {
    return this.helper_bcbuvs$_0.niceFormat();
  };
  BillType.prototype.shortLabel = function () {
    return this.shortLabel_bcbuvs$_0;
  };
  BillType.$metadata$ = {
    kind: Kotlin.Kind.CLASS,
    simpleName: 'BillType',
    interfaces: [VisibleType, Enum]
  };
  function BillType$values() {
    return [BillType$NONE_getInstance(), BillType$SENATE_BILL_getInstance(), BillType$HOUSE_BILL_getInstance(), BillType$SENATE_RESOLUTION_getInstance(), BillType$HOUSE_RESOLUTION_getInstance(), BillType$SENATE_CONCURRENT_RESOLUTION_getInstance(), BillType$HOUSE_CONCURRENT_RESOLUTION_getInstance(), BillType$SENATE_JOINT_RESOLUTION_getInstance(), BillType$HOUSE_JOINT_RESOLUTION_getInstance()];
  }
  BillType.values = BillType$values;
  function BillType$valueOf(name) {
    switch (name) {
      case 'NONE':
        return BillType$NONE_getInstance();
      case 'SENATE_BILL':
        return BillType$SENATE_BILL_getInstance();
      case 'HOUSE_BILL':
        return BillType$HOUSE_BILL_getInstance();
      case 'SENATE_RESOLUTION':
        return BillType$SENATE_RESOLUTION_getInstance();
      case 'HOUSE_RESOLUTION':
        return BillType$HOUSE_RESOLUTION_getInstance();
      case 'SENATE_CONCURRENT_RESOLUTION':
        return BillType$SENATE_CONCURRENT_RESOLUTION_getInstance();
      case 'HOUSE_CONCURRENT_RESOLUTION':
        return BillType$HOUSE_CONCURRENT_RESOLUTION_getInstance();
      case 'SENATE_JOINT_RESOLUTION':
        return BillType$SENATE_JOINT_RESOLUTION_getInstance();
      case 'HOUSE_JOINT_RESOLUTION':
        return BillType$HOUSE_JOINT_RESOLUTION_getInstance();
      default:Kotlin.throwISE('No enum constant bz.stew.bracken.model.types.bill.types.BillType.' + name);
    }
  }
  BillType.valueOf_61zpoe$ = BillType$valueOf;
  var package$bz = _.bz || (_.bz = {});
  var package$stew = package$bz.stew || (package$bz.stew = {});
  var package$bracken = package$stew.bracken || (package$stew.bracken = {});
  package$bracken.main_kand9s$ = main;
  package$bracken.printMajorActionData_vr7fzr$ = printMajorActionData;
  var package$controller = package$bracken.controller || (package$bracken.controller = {});
  package$controller.Controller = Controller;
  var package$extension = package$bracken.extension || (package$bracken.extension = {});
  package$extension.clamp_nl3q3x$ = clamp;
  package$extension.niceClamp_gsfqr0$ = niceClamp;
  var package$model = package$bracken.model || (package$bracken.model = {});
  package$model.BillModelGovTrack = BillModelGovTrack;
  package$model.Model = Model;
  package$model.ModelItem = ModelItem;
  var package$service = package$bracken.service || (package$bracken.service = {});
  package$service.RequestCallback = RequestCallback;
  package$service.ServerRequestDispatcher = ServerRequestDispatcher;
  Object.defineProperty(JsonUtil, 'Parse', {
    get: JsonUtil$Parse_getInstance
  });
  var package$util = package$bracken.util || (package$bracken.util = {});
  package$util.JsonUtil = JsonUtil;
  Object.defineProperty(Math_0, 'Ease', {
    get: Math$Ease_getInstance
  });
  package$util.Math = Math_0;
  var package$view = package$bracken.view || (package$bracken.view = {});
  package$view.HtmlGen = HtmlGen;
  package$view.HtmlSelector = HtmlSelector;
  package$view.View = View;
  package$view.ViewConstant = ViewConstant;
  package$view.ViewConstantHelper = ViewConstantHelper;
  Object.defineProperty(ViewConstants, 'Empty', {
    get: ViewConstants$Empty_getInstance
  });
  Object.defineProperty(ViewConstants, 'Introduced', {
    get: ViewConstants$Introduced_getInstance
  });
  Object.defineProperty(ViewConstants, 'Failed', {
    get: ViewConstants$Failed_getInstance
  });
  Object.defineProperty(ViewConstants, 'PassedHouse', {
    get: ViewConstants$PassedHouse_getInstance
  });
  Object.defineProperty(ViewConstants, 'PassedSenate', {
    get: ViewConstants$PassedSenate_getInstance
  });
  Object.defineProperty(ViewConstants, 'SignedByPresident', {
    get: ViewConstants$SignedByPresident_getInstance
  });
  Object.defineProperty(ViewConstants, 'EnactedLaw', {
    get: ViewConstants$EnactedLaw_getInstance
  });
  package$view.ViewConstants = ViewConstants;
  var package$bill = package$controller.bill || (package$controller.bill = {});
  package$bill.BillController = BillController;
  var package$request = package$controller.request || (package$controller.request = {});
  package$request.DataRequest = DataRequest;
  var package$html = package$extension.html || (package$extension.html = {});
  package$html.jsDate_qt1dr2$ = jsDate;
  package$html.jsDate_tjonv8$ = jsDate_0;
  package$html.jsDate = jsDate_1;
  package$html.elementFixedOffset_r9rwt9$ = elementFixedOffset;
  package$html.each_qdflk5$ = each;
  package$html.eachChildClass_6vk4um$ = eachChildClass;
  package$html.eachChildId_as6kxx$ = eachChildId;
  package$html.asList_ejp6nk$ = asList_0;
  package$html.emptyList_ejp6nk$ = emptyList;
  var package$jquery = package$extension.jquery || (package$extension.jquery = {});
  package$jquery.fadeIn_v89ba5$ = fadeIn;
  package$jquery.get_fjcsf1$ = get;
  package$jquery.hide_vwohdt$ = hide;
  package$jquery.hide_fjcsf1$ = hide_0;
  package$jquery.hide_v89ba5$ = hide_1;
  package$jquery.show_vwohdt$ = show;
  package$jquery.show_fjcsf1$ = show_0;
  package$jquery.show_v89ba5$ = show_1;
  package$jquery.append_5kxll9$ = append;
  package$jquery.children_5kxll9$ = children_0;
  package$jquery.children_vwohdt$ = children;
  package$jquery.children_v89ba5$ = children_1;
  package$jquery.first_vwohdt$ = first;
  package$jquery.remove_vwohdt$ = remove;
  package$jquery.remove_v89ba5$ = remove_0;
  package$jquery.css_zc05ld$ = css;
  package$jquery.velocity_c87r3m$ = velocity;
  var package$index = package$model.index || (package$model.index = {});
  package$index.AbstractMappedIndex = AbstractMappedIndex;
  Object.defineProperty(package$index, 'STATUS_INDEX', {
    get: function () {
      return STATUS_INDEX;
    }
  });
  Object.defineProperty(package$index, 'MAJOR_STATUS_INDEX', {
    get: function () {
      return MAJOR_STATUS_INDEX;
    }
  });
  Object.defineProperty(package$index, 'PARTY_INDEX', {
    get: function () {
      return PARTY_INDEX;
    }
  });
  Object.defineProperty(package$index, 'INTRO_DATE_INDEX', {
    get: function () {
      return INTRO_DATE_INDEX;
    }
  });
  Object.defineProperty(package$index, 'LAST_UPDATED_DATE_INDEX', {
    get: function () {
      return LAST_UPDATED_DATE_INDEX;
    }
  });
  Object.defineProperty(package$index, 'EMPTY_INDEX', {
    get: function () {
      return EMPTY_INDEX;
    }
  });
  Object.defineProperty(package$index, 'ALL_INDEX_DEFS', {
    get: function () {
      return ALL_INDEX_DEFS;
    }
  });
  Object.defineProperty(IndexDefinitions, 'Companion', {
    get: IndexDefinitions$Companion_getInstance
  });
  package$index.IndexDefinitions = IndexDefinitions;
  package$index.Indexed = Indexed;
  Object.defineProperty(IndexEnum, 'NONE', {
    get: IndexEnum$NONE_getInstance
  });
  Object.defineProperty(IndexEnum, 'FixedStatusIndex', {
    get: IndexEnum$FixedStatusIndex_getInstance
  });
  Object.defineProperty(IndexEnum, 'IntroDate', {
    get: IndexEnum$IntroDate_getInstance
  });
  Object.defineProperty(IndexEnum, 'LastUpdatedDate', {
    get: IndexEnum$LastUpdatedDate_getInstance
  });
  Object.defineProperty(IndexEnum, 'LastMajorStatus', {
    get: IndexEnum$LastMajorStatus_getInstance
  });
  package$index.IndexEnum = IndexEnum;
  Object.defineProperty(IndexOperation, 'GreaterThanOrEqual', {
    get: IndexOperation$GreaterThanOrEqual_getInstance
  });
  Object.defineProperty(IndexOperation, 'LessThanOrEqual', {
    get: IndexOperation$LessThanOrEqual_getInstance
  });
  package$index.IndexOperation = IndexOperation;
  package$index.MappedIndex = MappedIndex;
  package$index.NumericDoubleAbstractMappedIndex = NumericDoubleAbstractMappedIndex;
  var package$types = package$model.types || (package$model.types = {});
  package$types.EPTypeHelper = EPTypeHelper;
  package$types.VisibleType = VisibleType;
  var package$animation = package$util.animation || (package$util.animation = {});
  package$animation.Animation = Animation;
  Object.defineProperty(LogLevel, 'SILENT', {
    get: LogLevel$SILENT_getInstance
  });
  Object.defineProperty(LogLevel, 'ERROR', {
    get: LogLevel$ERROR_getInstance
  });
  Object.defineProperty(LogLevel, 'WARNING', {
    get: LogLevel$WARNING_getInstance
  });
  Object.defineProperty(LogLevel, 'INFO', {
    get: LogLevel$INFO_getInstance
  });
  Object.defineProperty(LogLevel, 'DEBUG', {
    get: LogLevel$DEBUG_getInstance
  });
  var package$log = package$util.log || (package$util.log = {});
  package$log.LogLevel = LogLevel;
  Object.defineProperty(Log, 'LogCompanion', {
    get: Log$LogCompanion_getInstance
  });
  package$log.Log = Log;
  Object.defineProperty(UIFormatter, 'DateCompanion', {
    get: UIFormatter$DateCompanion_getInstance
  });
  var package$ui = package$util.ui || (package$util.ui = {});
  package$ui.UIFormatter = UIFormatter;
  var package$bill_0 = package$view.bill || (package$view.bill = {});
  package$bill_0.BillView = BillView;
  Object.defineProperty(Form, 'Option', {
    get: Form$Option_getInstance
  });
  var package$html_0 = package$view.html || (package$view.html = {});
  package$html_0.Form = Form;
  Object.defineProperty(Identifier, 'ID', {
    get: Identifier$ID_getInstance
  });
  Object.defineProperty(Identifier, 'CLASS', {
    get: Identifier$CLASS_getInstance
  });
  Object.defineProperty(Identifier, 'TAG', {
    get: Identifier$TAG_getInstance
  });
  package$html_0.Identifier = Identifier;
  var package$item = package$view.item || (package$view.item = {});
  package$item.BillViewItem = BillViewItem;
  package$item.ViewItem = ViewItem;
  Object.defineProperty(BillFilters, 'IDENTITY', {
    get: BillFilters$IDENTITY_getInstance
  });
  Object.defineProperty(BillFilters, 'PARTY', {
    get: BillFilters$PARTY_getInstance
  });
  Object.defineProperty(BillFilters, 'FIXEDSTATUS', {
    get: BillFilters$FIXEDSTATUS_getInstance
  });
  Object.defineProperty(BillFilters, 'DATEINTROSTART', {
    get: BillFilters$DATEINTROSTART_getInstance
  });
  Object.defineProperty(BillFilters, 'DATEINTROEND', {
    get: BillFilters$DATEINTROEND_getInstance
  });
  Object.defineProperty(BillFilters, 'LASTUPDATEDDATESTART', {
    get: BillFilters$LASTUPDATEDDATESTART_getInstance
  });
  Object.defineProperty(BillFilters, 'LASTUPDATEDDATEEND', {
    get: BillFilters$LASTUPDATEDDATEEND_getInstance
  });
  Object.defineProperty(BillFilters, 'LASTMAJORSTATUS', {
    get: BillFilters$LASTMAJORSTATUS_getInstance
  });
  var package$filter = package$bill.filter || (package$bill.filter = {});
  package$filter.BillFilters = BillFilters;
  package$filter.FilterEntry = FilterEntry;
  var package$kotlin = package$extension.kotlin || (package$extension.kotlin = {});
  var package$collections = package$kotlin.collections || (package$kotlin.collections = {});
  package$collections.flattenValueSets_4a4nh3$ = flattenValueSets;
  package$collections.flatten_4c7yge$ = flatten;
  var package$bill_1 = package$types.bill || (package$types.bill = {});
  package$bill_1.BillData = BillData;
  package$bill_1.BillProxy = BillProxy;
  package$bill_1.MajorAction = MajorAction;
  package$bill_1.emptyMajorAction = emptyMajorAction;
  package$bill_1.RelatedBills = RelatedBills;
  Object.defineProperty(Party, 'NONE', {
    get: Party$NONE_getInstance
  });
  Object.defineProperty(Party, 'DEMOCRAT', {
    get: Party$DEMOCRAT_getInstance
  });
  Object.defineProperty(Party, 'DEMON', {
    get: Party$DEMON_getInstance
  });
  Object.defineProperty(Party, 'REPUBLICAN', {
    get: Party$REPUBLICAN_getInstance
  });
  Object.defineProperty(Party, 'INDEPENDENT', {
    get: Party$INDEPENDENT_getInstance
  });
  var package$party = package$types.party || (package$types.party = {});
  package$party.Party = Party;
  var package$person = package$types.person || (package$types.person = {});
  package$person.Legislator = Legislator;
  Object.defineProperty(package$person, 'EMPTY_LEG', {
    get: function () {
      return EMPTY_LEG;
    }
  });
  package$person.emptyLegislator = emptyLegislator;
  Object.defineProperty(LegislatorRole, 'NONE', {
    get: LegislatorRole$NONE_getInstance
  });
  Object.defineProperty(LegislatorRole, 'SENATOR', {
    get: LegislatorRole$SENATOR_getInstance
  });
  Object.defineProperty(LegislatorRole, 'REPRESENTATIVE', {
    get: LegislatorRole$REPRESENTATIVE_getInstance
  });
  package$person.LegislatorRole = LegislatorRole;
  package$person.Person = Person;
  var package$govtrack = package$bill_1.govtrack || (package$bill_1.govtrack = {});
  package$govtrack.BillDataGovTrack = BillDataGovTrack;
  package$govtrack.GovTrackMajorAction = GovTrackMajorAction;
  var package$status = package$bill_1.status || (package$bill_1.status = {});
  package$status.BillStatus = BillStatus;
  Object.defineProperty(package$status, 'EMPTY_BILL_STATUS', {
    get: function () {
      return EMPTY_BILL_STATUS;
    }
  });
  package$status.emptyBillStatus = emptyBillStatus;
  Object.defineProperty(FixedStatus, 'NONE', {
    get: FixedStatus$NONE_getInstance
  });
  Object.defineProperty(FixedStatus, 'prov_kill_veto', {
    get: FixedStatus$prov_kill_veto_getInstance
  });
  Object.defineProperty(FixedStatus, 'fail_second_senate', {
    get: FixedStatus$fail_second_senate_getInstance
  });
  Object.defineProperty(FixedStatus, 'passed_bill', {
    get: FixedStatus$passed_bill_getInstance
  });
  Object.defineProperty(FixedStatus, 'passed_constamend', {
    get: FixedStatus$passed_constamend_getInstance
  });
  Object.defineProperty(FixedStatus, 'pass_back_senate', {
    get: FixedStatus$pass_back_senate_getInstance
  });
  Object.defineProperty(FixedStatus, 'vetoed_override_fail_second_house', {
    get: FixedStatus$vetoed_override_fail_second_house_getInstance
  });
  Object.defineProperty(FixedStatus, 'fail_originating_house', {
    get: FixedStatus$fail_originating_house_getInstance
  });
  Object.defineProperty(FixedStatus, 'fail_second_house', {
    get: FixedStatus$fail_second_house_getInstance
  });
  Object.defineProperty(FixedStatus, 'override_pass_over_house', {
    get: FixedStatus$override_pass_over_house_getInstance
  });
  Object.defineProperty(FixedStatus, 'override_pass_over_senate', {
    get: FixedStatus$override_pass_over_senate_getInstance
  });
  Object.defineProperty(FixedStatus, 'pass_back_house', {
    get: FixedStatus$pass_back_house_getInstance
  });
  Object.defineProperty(FixedStatus, 'prov_kill_cloturefailed', {
    get: FixedStatus$prov_kill_cloturefailed_getInstance
  });
  Object.defineProperty(FixedStatus, 'enacted_veto_override', {
    get: FixedStatus$enacted_veto_override_getInstance
  });
  Object.defineProperty(FixedStatus, 'passed_concurrentres', {
    get: FixedStatus$passed_concurrentres_getInstance
  });
  Object.defineProperty(FixedStatus, 'prov_kill_suspensionfailed', {
    get: FixedStatus$prov_kill_suspensionfailed_getInstance
  });
  Object.defineProperty(FixedStatus, 'passed_simpleres', {
    get: FixedStatus$passed_simpleres_getInstance
  });
  Object.defineProperty(FixedStatus, 'vetoed_pocket', {
    get: FixedStatus$vetoed_pocket_getInstance
  });
  Object.defineProperty(FixedStatus, 'vetoed_override_fail_originating_house', {
    get: FixedStatus$vetoed_override_fail_originating_house_getInstance
  });
  Object.defineProperty(FixedStatus, 'conference_passed_senate', {
    get: FixedStatus$conference_passed_senate_getInstance
  });
  Object.defineProperty(FixedStatus, 'fail_originating_senate', {
    get: FixedStatus$fail_originating_senate_getInstance
  });
  Object.defineProperty(FixedStatus, 'pass_over_senate', {
    get: FixedStatus$pass_over_senate_getInstance
  });
  Object.defineProperty(FixedStatus, 'prov_kill_pingpongfail', {
    get: FixedStatus$prov_kill_pingpongfail_getInstance
  });
  Object.defineProperty(FixedStatus, 'enacted_signed', {
    get: FixedStatus$enacted_signed_getInstance
  });
  Object.defineProperty(FixedStatus, 'pass_over_house', {
    get: FixedStatus$pass_over_house_getInstance
  });
  Object.defineProperty(FixedStatus, 'conference_passed_house', {
    get: FixedStatus$conference_passed_house_getInstance
  });
  Object.defineProperty(FixedStatus, 'reported', {
    get: FixedStatus$reported_getInstance
  });
  Object.defineProperty(FixedStatus, 'vetoed_override_fail_second_senate', {
    get: FixedStatus$vetoed_override_fail_second_senate_getInstance
  });
  Object.defineProperty(FixedStatus, 'vetoed_override_fail_originating_senate', {
    get: FixedStatus$vetoed_override_fail_originating_senate_getInstance
  });
  Object.defineProperty(FixedStatus, 'enacted_tendayrule', {
    get: FixedStatus$enacted_tendayrule_getInstance
  });
  Object.defineProperty(FixedStatus, 'introduced', {
    get: FixedStatus$introduced_getInstance
  });
  Object.defineProperty(FixedStatus, 'enacted_unknown', {
    get: FixedStatus$enacted_unknown_getInstance
  });
  Object.defineProperty(FixedStatus, 'referred', {
    get: FixedStatus$referred_getInstance
  });
  Object.defineProperty(FixedStatus, 'Companion', {
    get: FixedStatus$Companion_getInstance
  });
  package$status.FixedStatus = FixedStatus;
  Object.defineProperty(MajorStatus, 'NONE', {
    get: MajorStatus$NONE_getInstance
  });
  Object.defineProperty(MajorStatus, 'INTRODUCED', {
    get: MajorStatus$INTRODUCED_getInstance
  });
  Object.defineProperty(MajorStatus, 'FAILED', {
    get: MajorStatus$FAILED_getInstance
  });
  Object.defineProperty(MajorStatus, 'PASSED_HOUSE', {
    get: MajorStatus$PASSED_HOUSE_getInstance
  });
  Object.defineProperty(MajorStatus, 'PASSED_SENATE', {
    get: MajorStatus$PASSED_SENATE_getInstance
  });
  Object.defineProperty(MajorStatus, 'SIGNED_PRESIDENT', {
    get: MajorStatus$SIGNED_PRESIDENT_getInstance
  });
  Object.defineProperty(MajorStatus, 'LAW', {
    get: MajorStatus$LAW_getInstance
  });
  Object.defineProperty(MajorStatus, 'Companion', {
    get: MajorStatus$Companion_getInstance
  });
  package$status.MajorStatus = MajorStatus;
  Object.defineProperty(BillResolutionType, 'NONE', {
    get: BillResolutionType$NONE_getInstance
  });
  Object.defineProperty(BillResolutionType, 'BILL', {
    get: BillResolutionType$BILL_getInstance
  });
  Object.defineProperty(BillResolutionType, 'RESOLUTION', {
    get: BillResolutionType$RESOLUTION_getInstance
  });
  var package$types_0 = package$bill_1.types || (package$bill_1.types = {});
  package$types_0.BillResolutionType = BillResolutionType;
  Object.defineProperty(BillType, 'NONE', {
    get: BillType$NONE_getInstance
  });
  Object.defineProperty(BillType, 'SENATE_BILL', {
    get: BillType$SENATE_BILL_getInstance
  });
  Object.defineProperty(BillType, 'HOUSE_BILL', {
    get: BillType$HOUSE_BILL_getInstance
  });
  Object.defineProperty(BillType, 'SENATE_RESOLUTION', {
    get: BillType$SENATE_RESOLUTION_getInstance
  });
  Object.defineProperty(BillType, 'HOUSE_RESOLUTION', {
    get: BillType$HOUSE_RESOLUTION_getInstance
  });
  Object.defineProperty(BillType, 'SENATE_CONCURRENT_RESOLUTION', {
    get: BillType$SENATE_CONCURRENT_RESOLUTION_getInstance
  });
  Object.defineProperty(BillType, 'HOUSE_CONCURRENT_RESOLUTION', {
    get: BillType$HOUSE_CONCURRENT_RESOLUTION_getInstance
  });
  Object.defineProperty(BillType, 'SENATE_JOINT_RESOLUTION', {
    get: BillType$SENATE_JOINT_RESOLUTION_getInstance
  });
  Object.defineProperty(BillType, 'HOUSE_JOINT_RESOLUTION', {
    get: BillType$HOUSE_JOINT_RESOLUTION_getInstance
  });
  package$types_0.BillType = BillType;
  EMPTY_LIST = ArrayList_init();
  STATUS_INDEX = new STATUS_INDEX$ObjectLiteral(FixedStatus$NONE_getInstance());
  MAJOR_STATUS_INDEX = new MAJOR_STATUS_INDEX$ObjectLiteral(MajorStatus$NONE_getInstance());
  PARTY_INDEX = new PARTY_INDEX$ObjectLiteral(Party$NONE_getInstance());
  INTRO_DATE_INDEX = new INTRO_DATE_INDEX$ObjectLiteral();
  LAST_UPDATED_DATE_INDEX = new LAST_UPDATED_DATE_INDEX$ObjectLiteral();
  EMPTY_INDEX = new EMPTY_INDEX$ObjectLiteral(null);
  ALL_INDEX_DEFS = listOf([STATUS_INDEX, PARTY_INDEX, INTRO_DATE_INDEX, LAST_UPDATED_DATE_INDEX, MAJOR_STATUS_INDEX]);
  logs = new Log();
  emptyAction = new emptyAction$ObjectLiteral();
  EMPTY_LEG = new Legislator(-1, '', Party$DEMON_getInstance(), LegislatorRole$NONE_getInstance(), 'NOSTATE', 'The_Donald');
  dateRegex = Regex('datetime\\.datetime\\((\\d{4}),\\s{0,1}(\\d{1,2}),\\s{0,1}(\\d{1,2})');
  EMPTY_BILL_STATUS = new BillStatus(FixedStatus$NONE_getInstance(), new Date(), 'EMPTY', 'EMPTY');
  Kotlin.defineModule('easypolitics-ui', _);
  main([]);
  return _;
}));

//@ sourceMappingURL=easypolitics-ui.js.map
